function submeterdados(){
	
	var f = document.getElementById("formLogin");
	var login = document.getElementById("login");
    var password = document.getElementById("password");
    
    if(login.value == "") {
        alert("You must type a login!");
        login.select();
        login.focus();
    } else  if(password.value == "") {
        alert("You must type a password!");
        password.select();
        password.focus();
    } else {
        document.getElementById("operation").value = "login";
	
}
