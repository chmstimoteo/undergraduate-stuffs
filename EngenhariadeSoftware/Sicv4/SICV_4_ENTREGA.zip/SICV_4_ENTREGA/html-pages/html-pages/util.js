function classification(){ //Array de GLatLng()
//points, pOcurrence	

	var points = [new GLatLng(-10.1,-35.1),new GLatLng(-9.2,-35.2),new GLatLng(-8.3,-35.3), new GLatLng(-8.4,-35.4), new GLatLng(-8.5,-35.5)]; 
	var pOcurrence = new GLatLng(-8.0,-35.0);
	var distances = new Array(points.length);	

	for(i=0; i<points.length; i++){
		distances[i] = points[i].distanceFrom(pOcurrence);
	}
	
	//alert(distances[0] + " " +distances[1] + " "+distances[2] + " "+distances[3] + " "+distances[4]);
	
	
	/*for(j=0;  j<distances.length-1; j++){
		var menor = j;
		
		for(k=j+1; k<distances.length; k++){
			if(distances[menor] > distances[k]){
				var temp = distances[menor];
				distances[menor] = distances[k];
				distances[k] = temp;
		}	
	}
	}*/
	
	distances.sort(ordenar);
	
	var result = new Array(5);
	
	for(j=0;  j<5; j++){
		result[j] = distances[j];
	}
	
	alert(distances[0] + "\n" +distances[1] + " \n"+distances[2] + " \n"+distances[3] + "\n "+distances[4]);
	//return result;
	
}


function ordenar(a,b){
	return (a-b);
}