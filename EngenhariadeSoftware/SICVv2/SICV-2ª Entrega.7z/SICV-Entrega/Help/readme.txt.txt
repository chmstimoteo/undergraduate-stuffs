-----------------------------------------------------------------------------------------------
Data:18 de Abril de 2008
SICV - Sistema Integrado de Controle de Viaturas
Universidade de Pernambuco(UPE) - Recife - PE - Brasil
Desenvolvimento:
	a. Carlos Henrique Maciel Sobral Timoteo 
	b. Diego Albuquerque de Ara�jo 
	c. Elliackin Messias do Nascimento Figueiredo 
	d. Rafael Praxedes Gomes
Estudantes de Gradua��o - Engenharia da Computa��o
5� per�odo
Disciplina: Engenharia de Software
Professor: Fernando Castor
-----------------------------------------------------------------------------------------------
------------------------| README.TXT |---------------------------------------------------------
-----------------------------------------------------------------------------------------------

*Instala��o de Componentes Necess�rios:

	Tomcat 6.0.16:
			http://tomcat.apache.org/





*Instru��es de USO:

	1-Para o Tomcat:

		1.1-Colocar a pasta do projeto na pasta webapps.
		1.2-Rodar o Tomcat
		1.3-abrir o browser escrever http://localhost:8080\attendant


	2-Para o Banco de Dados Access:

		2.1-Painel de Controle
		2.2-Ferramentas administrativas
		2.3-Fonde de Dados(ODBC)
		2.4-aperte o bot�o adicionar
		2.5-Selecione Driver do Microsoft Access e aperte Concluir
		2.6-coloque o nome sicv no campo Nome
		2.7-coloque qualquer coisa na descri��o
		2.8-selecione o bano de dados como o nome sicv.
		2.9-aperte OK.


	3-Para compilar os Testes Autom�ticos do JUnit:

		3.1-Abra o Eclipse
		3.2-No menu "File", clique em "Import..."
		3.3-Clique "Existing Projects Into Workspace"
		3.4-Procure o arquivo no sistema e finalize.
		3.5-Acesse o pacote sicv/testes
		3.6-Clique com o botao direito na classe "AllTest.java" e run as... "JUnit Tests".




Obs.: Caso voce tenha problemas mesmo ap�s ter feito todas essas instru��es, procure ver se vc
tem todos Componentes Necess�rios para a Instala��o e se os arquivos n�o est�o corrompidos.



Qualquer duvida, Email us:
		
		Carlos Henrique Maciel Sobral Timoteo  = carlos_timoteo@yahoo.com.br
		Diego Albuquerque de Ara�jo  = diego.araujo19@gmail.com
		Elliackin Messias do Nascimento Figueiredo  = elliackin@gmail.com
		Rafael Praxedes Gomes  = rafaprax28@gmail.com