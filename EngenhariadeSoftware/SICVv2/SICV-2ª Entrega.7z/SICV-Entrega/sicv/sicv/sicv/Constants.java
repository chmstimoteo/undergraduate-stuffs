package sicv;


public class Constants {

	public static final String ICON_HREF = "";
	public static String NOT_INFORMED ="NOT INFORMED";
	public static int MAX_OCCURRENCES_BY_AGENT = 3;
	public static String PATH_XML_POSITION = "C:\\Program Files\\Apache Software Foundation\\Tomcat 6.0\\webapps\\sicv\\markers.xml";
	public static final String DB_URL = "jdbc:odbc:sicv";
	public static final String DB_LOGIN = "";
	public static final String DB_PASS = "";
	public static final String DB_DRIVER = "sun.jdbc.odbc.JdbcOdbcDriver";
	public static boolean isPersistent() {
		return true;
	}
}
