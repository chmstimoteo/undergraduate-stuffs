
var lat;
var lng;

function send()
{
   var form = document.getElementById("form");
   
   form.lat.value = lat;
   form.lng.value = lng;
   
   form.submit();
   
}

function Call(){

if (GBrowserIsCompatible()) {
 
      var map = new GMap2(document.getElementById("map"));
      map.setCenter(new GLatLng(53.7877, -2.9832),15)
      map.addControl(new GLargeMapControl());
      map.addControl(new GMapTypeControl());
      var dirn = new GDirections();

      GEvent.addListener(map, "click", function(overlay,point) {
        // == When the user clicks on a the map, get directiobns from that point to itself ==
        if (!overlay) {
          dirn.loadFromWaypoints([point.toUrlValue(6),point.toUrlValue(6)],{getPolyline:true});
        }
        if (overlay) {
          map.removeOverlay(overlay);
        }
      });

      // == when the load event completes, plot the point on the street ==
      GEvent.addListener(dirn,"load", function() {
        var p=dirn.getPolyline().getVertex(0);
        map.addOverlay(new GMarker(p));
        lat = p.lat();
        lng = p.lng();        
      });

      GEvent.addListener(dirn,"error", function() {
        GLog.write("Failed: "+dirn.getStatus().code);
      });

    }
    else {
      alert("Sorry, the Google Maps API is not compatible with this browser");
    }
    
    
 }