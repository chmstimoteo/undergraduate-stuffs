package sicv.model.occurrence;

public enum Priority {

	
		
		HIGH (2),
		AVERAGE(1),
		LOW (0);
		
		
		private int priority;
		
		Priority(int priority) {
	        this.priority = priority;
	    }
	   
	   
}
