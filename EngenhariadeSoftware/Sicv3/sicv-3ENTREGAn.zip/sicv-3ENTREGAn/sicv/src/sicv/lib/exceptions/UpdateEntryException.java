package sicv.lib.exceptions;

public class UpdateEntryException extends Exception {

	
	private static final long serialVersionUID = -2322904490309174400L;

	public UpdateEntryException() {
		super();
		
	}

	public UpdateEntryException(String arg0) {
		super(arg0);
		
	}

	public UpdateEntryException(String arg0, Throwable arg1) {
		super(arg0, arg1);
		
	}

	public UpdateEntryException(Throwable arg0) {
		super(arg0);
		
	}

}
