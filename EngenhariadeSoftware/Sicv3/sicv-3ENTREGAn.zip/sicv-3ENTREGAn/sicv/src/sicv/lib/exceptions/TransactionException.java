package sicv.lib.exceptions;

public class TransactionException extends Exception {

	
	private static final long serialVersionUID = 7839004804039601399L;

	public TransactionException(String s) {
		super(s);
	}
}
