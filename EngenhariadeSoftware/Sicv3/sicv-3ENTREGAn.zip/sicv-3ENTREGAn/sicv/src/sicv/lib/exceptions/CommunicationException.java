package sicv.lib.exceptions;

public class CommunicationException extends Exception implements java.io.Serializable {

    /**
	 * 
	 */
	private static final long serialVersionUID = -7510363927773375896L;

	public CommunicationException(String s) {
        super(s);
    }
}


