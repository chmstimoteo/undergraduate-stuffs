package sicv.lib.exceptions;

public class InsertEntryException extends Exception {

	private static final long serialVersionUID = 5836901571046773842L;

	public InsertEntryException() {
		super();
		
	}

	public InsertEntryException(String arg0) {
		super(arg0);
		
	}

	public InsertEntryException(String arg0, Throwable arg1) {
		super(arg0, arg1);
		
	}

	public InsertEntryException(Throwable arg0) {
		super(arg0);
		
	}

	public InsertEntryException(Exception e) {
		super(e);
	}

}
