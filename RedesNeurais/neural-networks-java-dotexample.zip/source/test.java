
import java.awt.*;
import java.awt.event.*;
import java.io.*;
import nnetwork.*;

import java.util.*;

public class test extends Frame implements ActionListener
{
		
	
	Network net;
	
	Button learnB = new Button( "learn from the TRN" );
	
	Button runB = new Button( "test" );
	
	public test()
	{
	  Properties prop = new Properties();
		
		try
		{
			prop.load( new FileInputStream("init.txt") );
			
			int NoHidden = Integer.parseInt( (String)prop.get( "hiddenNo" ) );
			
			int PenNoHidden[] = new int[NoHidden];
			
			for( int i=1; i<NoHidden+1; i++ )
        PenNoHidden[i-1] = Integer.parseInt( (String)prop.get( "hidden"+i ) );
 			
			int NoOut = Integer.parseInt( (String)prop.get( "outputNo" ) );
			int inNo = Integer.parseInt( (String)prop.get( "inputNo" ) );
			double learnRate = Double.parseDouble( (String)prop.get( "learnrate" ) );
			double aprox = Double.parseDouble( (String)prop.get( "aprox" ) );
		  
			net = new Network( PenNoHidden, NoOut, inNo, learnRate, aprox );
		}
		catch( Exception e )
		{
			System.out.println( e );
			System.exit( 0 );
		}
		
		learnB.addActionListener( this );
		runB.addActionListener( this );
		this.setLayout( new FlowLayout() );
		this.add( learnB );
		this.add( runB );
		setSize( 200, 200 );
		show();
	}		
	
	private void learnB_Hit()
	{
    startStop();		
	}
	
	
	private void runB_Hit()
	{
		try{
		  FileInputStream inS = new FileInputStream( "test.file" );
			Properties prop = new Properties();
			
		  prop.load( inS );
			
			StringTokenizer tokenizer;
			
			tokenizer = new StringTokenizer( (String)prop.get( "vector" ), "," );
			
			double vector[] = new double[tokenizer.countTokens()];
			
			int i=0;
			while( tokenizer.hasMoreTokens() )
			{
				vector[i] = Double.parseDouble( tokenizer.nextToken() );
				i++;
			}
			
			
			double[] results = net.getResults( vector );
		  
			
			System.out.println("results size="+results.length);
			System.out.println( "--results--" );
			for( int j=0; j<results.length;j++ )
				System.out.print( results[j]+" ,");
			System.out.print( "\n\n--end results--" );
				inS.close();
				 
		}
		catch( Exception e )
		{
			System.out.println( "In :"+e );
		}
		
		
	}
	public void actionPerformed( ActionEvent e )
	{
		if( e.getSource() == learnB )
			learnB_Hit();
			if( e.getSource() == runB )
				runB_Hit();
	}
	
	public void startTheTrainer()
	{
		//START THE THREAD TRAINING
		System.out.println("START THE THREAD TRAINING");
		if( theTrainer == null )
	  {
			theTrainer = new Trainer();
			theTrainer.start();
	  }
	}
	
	Trainer theTrainer;
	public void startStop()
	{
		if( theTrainer == null )
		{
			startTheTrainer();
		}
		else
			stopTheTrainer();
	}
	
	
	public void stopTheTrainer()
	{
		//STOP THE THREAD TRAINING
		System.out.println("STOP THE THREAD TRAINING");
		if( theTrainer!=null )
		{
			theTrainer.stop();
			theTrainer = null;
		}
	}
	
	public class Trainer extends Thread
	{
		public Trainer()
		{
			super();
		}
		
		public void run()
	  {
		  Properties prop = new Properties();
		  ArrayList trains = new ArrayList();
		  FileInputStream inS;
		 try{
		   inS = new FileInputStream("simple.trn");
		 }
		 catch( Exception e ){System.out.println("mas ta eprikses malakia "+e ); return;}
		 try
		 {
			prop.load( inS );
			
			StringTokenizer tokenizer;
			int i = 1;
			
			double[] in;
			double[] out;
			int j = 0;
			while( true )
			{
				
				//get The in(i)
				tokenizer = new StringTokenizer( (String)prop.get("in"+i), "," );
				in = new double[tokenizer.countTokens()];
				
				j = 0;
				while( tokenizer.hasMoreTokens() )
				{
					in[j] = Double.parseDouble( tokenizer.nextToken() );
					j++;
				}
				
				//get The out(i)
				tokenizer = new StringTokenizer( (String)prop.get("out"+i), "," );
				out = new double[tokenizer.countTokens()];
				
				j = 0;
				while( tokenizer.hasMoreTokens() )
				{
					out[j] = Double.parseDouble( tokenizer.nextToken() );
					j++;
				}
				i++;
				
				trains.add( new Train(in, out) );
			}			
		}
		catch( Exception e )
		{
			System.out.println( "Ayto:"+e );
			try{
			  if( inS != null)
			    inS.close();
			}
			catch( Exception ee ){ System.out.println("MALAKES "+ee ); }
		}
		System.out.println( "trains size = "+trains.size() );
			
		Train[] trainsA = new Train[trains.size()];
		trains.toArray(trainsA);
		
		Random rand = new Random();
				
		int NoTrains = trains.size();
				
		int i = 0;
		try{
		while( true )
		{
			i = rand.nextInt(NoTrains);
			if( !net.train( trainsA[i].getIn(), trainsA[i].getOut() ) )
			{
				trains.remove( i );
				NoTrains--;
				if( trains.size() == 0 )
				{
					System.out.println( "All learned" );
					Toolkit.getDefaultToolkit().beep();
					Thread.sleep(400);
					Toolkit.getDefaultToolkit().beep();
					Thread.sleep(400);
					Toolkit.getDefaultToolkit().beep();
					Thread.sleep(400);
					Toolkit.getDefaultToolkit().beep();
					break;
				}
				trainsA = new Train[trains.size()];
		    trains.toArray(trainsA);
				Toolkit.getDefaultToolkit().beep();
			 //System.out.println( "LEARNED" );
		  }
			else;
			 //System.out.println( "NOT LEARNED" );
		}
		}
		catch( Exception e){}
		stop();
		//net.train( trainsA );
	}

	}
	public static void main( String args[] )
	{
		test t = new test();
		t.addWindowListener(
		  new WindowAdapter()
			{
				public void windowClosing( WindowEvent e ){ System.exit( 0 ); }
			}
		);
	}
}