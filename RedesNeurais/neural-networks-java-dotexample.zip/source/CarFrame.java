import java.awt.*;
import java.awt.event.*;
import java.util.*;

import java.io.*;
import napps.*;
 
public class CarFrame extends Frame implements ActionListener
{
	
	CarPlace place;
	
	Button startB = new Button( "start" );
	Button saveB = new Button( "save brain" );
	Button loadB = new Button( "load brain" );
	public CarFrame()
	{
		setSize( 600, 600 );
		this.setLayout( new FlowLayout() );
		
		Properties prop = new Properties();
		try{
			FileInputStream s = new FileInputStream("carInit/carInit.txt");
		  prop.load( s );
		
		  int wid = Integer.parseInt( (String)prop.get( "width" ) );
			int hei = Integer.parseInt( (String)prop.get( "height" ) );
			int no= Integer.parseInt( (String)prop.get( "NoCars" ) );
			int pw= Integer.parseInt( (String)prop.get( "pwidth" ) );
			int ph= Integer.parseInt( (String)prop.get( "pheight" ) );
		  place = new CarPlace( wid, hei, no, pw, ph );
		  place.setVisible( true );
		
		  this.add( place );
		  s.close();
		}
		catch( Exception e ){}
		
		startB.addActionListener( this );
		saveB.addActionListener( this );
		loadB.addActionListener( this );
		this.add( startB );
		this.add( loadB );
		this.add( saveB );
		
		show();
	}
	
	public void loadB_Hit()
	{
		try{
			place.stop();
			
			FileInputStream fin = new FileInputStream ( "carInit/lastBrain.brn" );
		  ObjectInputStream in = new ObjectInputStream( fin );
			place.setBrains( (ArrayList)in.readObject() );
			
			in.close();			
			fin.close();
			
		}
		catch( Exception e ){ System.out.println( "Exception loading:"+e );}
	}
	private void saveB_Hit()
	{
		try{
			place.stop();
			FileOutputStream fout = new FileOutputStream ( "carInit/lastBrain.brn" ); 
		  ObjectOutputStream out = new ObjectOutputStream( fout );
			out.writeObject( place.getBrains() );
			
			out.close();
			fout.close();
		}
		catch( Exception e ){ System.out.println( "Exception saving:"+e ); }
		
		
	}
	
	private void startB_Hit()
	{
		place.startStop();
	}
	
	public void actionPerformed( ActionEvent e )
	{
		if( e.getSource() == startB )
			startB_Hit();
		else if( e.getSource() == loadB )
		  loadB_Hit();
		else if( e.getSource() == saveB )
		  saveB_Hit();
	}
	
	public static void main( String args[] )
	{
		CarFrame t = new CarFrame();
		t.addWindowListener(
		  new WindowAdapter()
			{
				public void windowClosing( WindowEvent e ){ System.exit( 0 ); }
			}
		);
	}
}