

public class RuntimeTest 
{
	public RuntimeTest( String args[] )	
	{
		
		try
		{
		  Runtime r = Runtime.getRuntime(); 
			//r.exec( args );
			System.out.println( "totalMemory="+r.totalMemory() );
			//System.out.println( "maxMemory="+r.maxMemory() );			
			System.out.println( "freeMemory="+r.freeMemory() );
			//System.out.println( "availableProcessors="+r.availableProcessors() );
			
			System.out.println( "done" );
		}
		catch( Exception e ){System.out.println( e );}
	}
	
	public static void main( String args[] )
	{
		RuntimeTest t = new RuntimeTest( args );
	}
}