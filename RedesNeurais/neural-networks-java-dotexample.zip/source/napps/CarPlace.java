package napps;

import java.util.*;
import nnetwork.*;

import java.awt.*;
import java.awt.event.*;
import java.io.Serializable;

public class CarPlace extends GridCanvas implements Runnable
{
	
	ArrayList worms = new ArrayList();
	
	private final int LEFT = 0;
	private final int RIGHT = 1;
	private final int DOWN = 2;
	private final int UP = 3;
	
	
	
	Thread runner;
	
	protected Color[] pallete = {Color.black, Color.green, Color.red};
	/**
	*
	*/
	public CarPlace( int width, int height, int NoWorms, int thisW, int thisH )
	{
		super( width, height, thisW, thisH );
		
		this.addKeyListener( new MyKeyAdapter() );		
		
		for( int i=0; i<NoWorms; i++ )
		{		  
			worms.add( new Worm() );
		}
		
		
		/*pallete = new Color[3];
		
		pallete[0] = Color.black;//space
		pallete[1] = Color.green; //head color
		pallete[2] = Color.red;// death color*/
		
		resetGrid();
	}
	
	public void update( Graphics g )
	{
		paint( g );
	}
	
	
	public ArrayList getBrains()
	{
		ArrayList brains = new ArrayList();
		
		for( int i=0; i<worms.size(); i++ )
		{
			Worm m = (Worm)worms.get( i );
			brains.add( m.getBrain() );
		}
		return brains;
	}
	
	public void setBrains( ArrayList brainList )
	{
		for( int i=0; i<=worms.size(); i++)
		{
			Worm m = (Worm)worms.remove( i );
		  m = null;
		}
		for( int i =0; i<brainList.size(); i++ )
		{
			worms.add( new Worm((Network)brainList.get( i )) );
		}		
		resetGrid();
		//repaint();
	}
	
	
	public void startStop()
	{
		if( runner == null )
			start();
		else
			stop();
	}
	private void resetGrid()
	{
		reset();
		
		for( int i=0; i<worms.size(); i++ )
		{
			Worm w = (Worm)worms.get( i );
			
			drawSquare( w.getHX(), w.getHY(), 1 );			
		}
		
		//drawSquare( 5, 5, 2 );
		//one draw the round red!!!
		for( int i=0; i<HNo; i++ )
		{
			drawSquare( i, 0, 2 );
			drawSquare( i, VNo-1, 2 );
		}
		for( int i=0; i<VNo; i++ )
		{
			drawSquare( 0, i, 2 );
			drawSquare( HNo-1, i, 2 );
		}
	}
		
	
	public void moveWorms()
	{
		for( int i=0; i<worms.size(); i++ )
		{
			Worm w = (Worm)worms.get( i );
			w.moveWorm();
		}
		
		repaint();
	}
	
	
	
	public void run()
	{
		while( true )
		{
			try
			{
			  Thread.sleep( 50 );
			}
			catch( Exception e ){}
			moveWorms();
		}
	}
	
	
	
	public void start()
	{
		if( runner == null )
		{
			runner = new Thread( this );
		  runner.start();
		}
	}
	
	public void stop()
	{
		if( runner !=null)
		{
			runner.stop();
			runner = null;
		}
	}
	
	double[] UP_VECTOR = {1,0,0,0};
	double[] DOWN_VECTOR = {0,1,0,0};
	double[] LEFT_VECTOR = {0,0,1,0};
	double[] RIGHT_VECTOR = {0,0,0,1};
	
	
	
	/**
	* returns a new direction or -1 if keep the previus one
	*
	* with aa great change to keep the old one
	*
	*/
	private int previousRand = 1;
	private int counter = 1;
	private int selectRandomDirection()
	{
		
		Random rand = new Random();
		int n = rand.nextInt( 20 );
		
		
		
		counter++;
		if( counter > 99000 )
			counter = 1;
		rand.setSeed( counter*System.currentTimeMillis() );
		
		if( n>4 )
			return -1;
		return rand.nextInt( 200 )%4;
	}
	
	private boolean vectorsEqual( double[] v1, double[] v2 )
	{
		if(v1.length != v2.length )
			return false;
			
		for( int i=0; i<v1.length; i++)
			if( (int)v1[i] != (int)v2[i] )
				return false;
		return true;
	}
	
	
	long upHitNo=0;
	long downHitNo=0;
	long leftHitNo=0;
	long rightHitNo=0;
	public class Worm implements Serializable 
	{
		private int headX, headY;		
		
		Network brain;
	  
		int pDirection=LEFT;
		
		public Worm( )
		{
		  RandCoor();
			brain = new Network( "carInit/carbrain.txt" );
		}
		
		public Worm( Network n )
		{
			brain = n;
		  RandCoor();
		}
		
		private void RandCoor()
		{
			Random rand = new Random();
			headX = rand.nextInt( HNo-2 )+1;
		
		  try{
		    Thread.sleep( 50 );
		  }
		  catch( Exception e ){}
		
		  rand.setSeed( System.currentTimeMillis() );
      headY = rand.nextInt( VNo-2 )+1;
		}
		
		public void moveWorm()
		{
      double round[] = getNeihbors( headX, headY );			
			double[] result = brain.getResults( round );
		  
			double[] results;
			
			results = new double[result.length];
			for( int i=0; i<results.length; i++ )
				results[i] = Math.rint( result[i] );
				
			
			if( vectorsEqual( results, LEFT_VECTOR) )
			{
				moveLeft();
				System.out.println( "Brain told LEFT" );
			}
			else if( vectorsEqual( results, RIGHT_VECTOR) )
			{
				moveRight();
				System.out.println( "Brain told RIGHT" );
			}
			else if( vectorsEqual( results, UP_VECTOR ) )
			{
			  moveUp();
				System.out.println( "Brain told UP" );
			}
			else if( vectorsEqual( results, DOWN_VECTOR ) )
			{
			  moveDown();
				System.out.println( "Brain told DOWN" );
			}
			else
				moveWorm( selectRandomDirection() );
		}
		
		public double[] getResultsOfCurrentLocation()
		{
			double round[] = getNeihbors( headX, headY );			
			double[] result = brain.getResults( round );
			
			return result;
		}
		
		private double[] getNeihbors( int X, int Y)
		{
			double[] input = new double[4];
			//up
			input[0] = (double)getGridColorID( X, Y-1 );
			//down
			input[1] = (double)getGridColorID( X, Y+1 );
			//left
			input[2] = (double)getGridColorID( X-1, Y );
			//right
			input[3] = (double)getGridColorID( X+1, Y );
			
			//input[4] = (double)pDirection;
			return input;
		}
		
		public double[] getDoubles( double array[] )
		{
			double[] d = new double[array.length];
		  
			for( int i=0; i< array.length; i++)
			  d[i] = (double)array[i];
			return d;
			
		}
		public void moveRight()
		{
			int px = headX;
			int py = headY;
			
			headX+=1;
			
			if( getGridColorID( headX, headY ) == 2 || getGridColorID( headX, headY ) == 1 )
			{
				double[] input = new double[4];
				
				input = getNeihbors( px, py );
				
				brain.train( input, getDoubles( LEFT_VECTOR ) );
				
				punish();
				++leftHitNo;
				//int s = selectRandomDirection();
				//if( s != -1)
				  //pDirection = s;
			  //headX-=1;
				//pDirection = LEFT;
			}
			pDirection = RIGHT;
			drawSquare( px, py, 0 );
			drawSquare( headX, headY, 1 );
			
		}
		
		public void moveLeft()
		{
			int px = headX;
			int py = headY;
			
			headX-=1;
			
			if( getGridColorID( headX, headY ) == 2 || getGridColorID( headX, headY ) == 1 )
			{
				double[] input = new double[4];
				
				input = getNeihbors( px, py );
				
				brain.train( input, getDoubles( RIGHT_VECTOR ) );
				
				punish();
				++rightHitNo;
				//int s = selectRandomDirection();
				//if( s != -1)
				  //pDirection = s;
				//headX+=1;
				//pDirection = RIGHT;
			}
			pDirection = LEFT;
			drawSquare( px, py, 0 );
			drawSquare( headX, headY, 1 );
			
		}
		
		private void punish()
		{
			headX = HNo/2;
			headY = VNo/2;
			
			//System.out.println( "Punish" );
		}
		public void moveUp()
		{
			int px = headX;
			int py = headY;
			
			headY-=1;
			
			if( getGridColorID( headX, headY ) == 2 || getGridColorID( headX, headY ) == 1 )
			{
				double[] input = new double[4];
				
				input = getNeihbors( px, py );
				
				brain.train( input, getDoubles( DOWN_VECTOR ) );
				
				punish();
				++upHitNo;
				
				//int s = selectRandomDirection();
				//if( s != -1)
				  //pDirection = s;
				//headY+=1;
				//pDirection = DOWN;
			}
			pDirection = UP;
			drawSquare( px, py, 0 );
			drawSquare( headX, headY, 1 );
			
		}
		public void moveDown()
		{			
			int px = headX;
			int py = headY;
			
			headY+=1;
			
			if( getGridColorID( headX, headY ) == 2 || getGridColorID( headX, headY ) == 1 )
			{
				double[] input = new double[4];
				
				input = getNeihbors( px, py );
				          
				brain.train( input, getDoubles( UP_VECTOR ) );
				
				punish();
				++downHitNo;
				//int s = selectRandomDirection();
				//if( s != -1)
				 // pDirection = s;
				//headY-=1;
				//pDirection = UP;
			}
			pDirection = DOWN;
			drawSquare( px, py, 0 );
			drawSquare( headX, headY, 1 );
			
		}
		
		public Network getBrain(){return brain;}
		
	 public void moveWorm( int direction )
	 {
		 if( direction == UP )
			 moveUp();
		 if( direction == DOWN )
			 moveDown();
		 if( direction == LEFT )
			 moveLeft();
		 if( direction == RIGHT )
			 moveRight();
		 if( direction == -1 )
			 moveWorm( pDirection );
	}
	
		public int getHX(){ return headX; }
		public int getHY(){ return headY; }
		//public int getTX(){ return tailX; }
		//public int getTY(){ return tailY; }
	}
	
	public class MyKeyAdapter extends KeyAdapter
	{
		public MyKeyAdapter()
	  {
		}
		
		
		
		public void keyPressed( KeyEvent e )
		{
			int code = e.getKeyCode(); 
        
			Worm worm = (Worm)worms.get( 0 ); 
			if( code == e.VK_UP )
			{
			  worm.moveWorm( UP );	
			}
			if( code == e.VK_DOWN )
			{
			  worm.moveWorm( DOWN );	
			}
			if( code == e.VK_LEFT )
			{
			  worm.moveWorm( LEFT );	
			}
			if( code == e.VK_RIGHT )
			{
			  worm.moveWorm( RIGHT );	
			}
			if( code == e.VK_H )
			{
				System.out.print("\n-----------HITS AT WALLS------------");
				System.out.print( "\nDOWN wall: "+downHitNo );
				System.out.print( "\nUP wall: "+upHitNo );
				System.out.print( "\nLEFT wall: "+leftHitNo );
				System.out.print( "\nRIGHT wall: "+rightHitNo );
			}
			if( code == e.VK_SPACE )
			{
				double res[] = worm.getResultsOfCurrentLocation();
				
				System.out.print("\nBrain results for current location\n");
				for( int i=0; i<res.length; i++ )
				{
					System.out.print( res[i]+", " );
				}	
				
				/*for( int i=0; i<worms.size(); i++ )
				{
					Worm m = (Worm)worms.get( i );
					
					System.out.println("\nWORM "+i+" brain values:");
					System.out.println()
				} */
			}
			repaint();
			  
		}
	}
}