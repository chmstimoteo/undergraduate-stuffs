package napps;

import java.awt.*;

public class GridCanvas extends Canvas
{
	
	protected int HNo, VNo;
	private int grid[][];
	
	protected int sqWidth, sqHeight; 
 
  protected Color[] pallete= {Color.black, Color.green, Color.red};
	
	public GridCanvas( int width, int height, int thisWidth, int thisHeight )
	{
		setSize( thisWidth, thisHeight );
		setBackground( Color.orange );
				
		HNo = width;
		VNo = height; 
    reset();		
	}
	
	public void reset()
	{		
		grid = new int[HNo][VNo];
		for( int i=0; i<HNo; i++ )
      for( int j=0; j<VNo; j++ )
				grid[i][j] = 0;
		initgr();
	}
	
	
	 void initgr() {

         Dimension d = getSize();
				 
				  sqWidth = d.width/HNo;
				  sqHeight = d.height/VNo;         
  }
	
	public void drawSquare( int x, int y, int colorNo )
	{		
		grid[x][y] = colorNo;
	}
	
	public void update( Graphics g )
	{
		paint( g );
	}
	public void paint( Graphics g )
	{
		initgr();
		/*System.out.println( "HNO=" + HNo);
		System.out.println( "VNO=" + VNo);
		System.out.println( "sqWidth=" + sqWidth);
		System.out.println( "sqHeight=" + sqHeight);*/
		
		
		//g.setColor( Color.yellow );
		//g.drawLine( 0, 0, 50, 50 );
		for( int i=0; i<HNo; i++ )
			for( int j=0; j<VNo; j++ )
			{
				g.setColor( pallete[grid[i][j]] );
				g.fillRect( i*sqWidth, j*sqHeight, sqWidth, sqHeight );
			}
	}
	
	public int getGridColorID( int x, int y ){return grid[x][y];}


   /*int iX(float x) 
	 { 
	   return Math.round(centerX+x/pixelSize); 
	 }
   int iY(float y) { return Math.round(centerY-y/pixelSize); }
   float fx(int X) { return (X-centerX)*pixelSize; }
   float fy(int Y) { return (centerY - Y) * pixelSize; }*/
}