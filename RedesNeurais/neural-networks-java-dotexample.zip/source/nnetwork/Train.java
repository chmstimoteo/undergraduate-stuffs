package nnetwork;

import java.io.Serializable;
public class Train implements Serializable 
	{
		private double[] in;
		private double[] out;
		public Train( double[] Tin, double[] Tout)
		{
			in = Tin;
			out = Tout;
		}
		
		public double[] getIn() { return in; }
		public double[] getOut(){ return out; } 
	}
	