
package nnetwork;

import java.io.Serializable;
/**
* This is a HiddenLayer apart from Perceptrons.
*
*/
public class InputLayer implements Serializable
{
	
	private int noInputs;
	
	private double inputs[];
	
	/**
	* @param   NoInputs       are actually the No outputs of the previus layer
	* @parm    NoPerceptron        how many nodes aparts of	
	*/
	public InputLayer( int NoInputs )
	{
		setNoInputs( NoInputs );
		inputs = new double[NoInputs];		
	}
	
	
	public double[] getInputs()
	{
		return inputs;
	}
	
	public void setInputs( double[] in )
	{
		inputs = in;
	}
	
	
	public void setNoInputs( int n ){ noInputs = n; }
	public int getNoInputs( ){ return noInputs; }
	
}