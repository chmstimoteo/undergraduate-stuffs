
package nnetwork;

import java.io.Serializable;
/**
* This is a HiddenLayer apart from Perceptrons.
*
*/
public class OutputLayer implements Serializable
{
	
	private int noInputs;
	
	private Perceptron perceptrons[];
	
	private boolean isOutput = true;
	
	private double learnRate = 0.1;
	/**
	* @param   NoInputs       are actually the No outputs of the previus layer
	* @param    NoPerceptron        how many nodes aparts of	
	*/
	public OutputLayer( int NoInputs, int NoPerceptron )
	{
		setNoInputs( NoInputs );		
			
		perceptrons = new Perceptron[NoPerceptron];
		
		for( int i=0; i<NoPerceptron; i++ )
		{
			//must find the initial value
			perceptrons[i] = new Perceptron( NoInputs );
		}
	}
	
	/**
	* @param   NoInputs             are actually the No outputs of the previus layer
	* @param   NoPerceptron        how many nodes aparts of
	* @param   learnRate           
	*/
	public OutputLayer( int NoInputs, int NoPerceptron, double learnR )
	{
		setNoInputs( NoInputs );		
		learnRate = learnR;
		
		perceptrons = new Perceptron[NoPerceptron];
		
		for( int i=0; i<NoPerceptron; i++ )
		{
			//must find the initial value
			perceptrons[i] = new Perceptron( NoInputs );
		}
	}
	
	public OutputLayer( Perceptron percs[], int NoInputs )
  {
    setNoInputs( NoInputs );
		perceptrons = percs;
	}
	
	/**
	* this is something like WORK!!! a coomand to get the outputs of this layer giving the inputs[]
  *
	* No need to override this. If you want to changing the algorithm just override the outputAlgorithm method
	*
	* @param    inputs                   the inputs
	* @returns                           the ouput vector of this layer as an array 
	*/
	public double[] GetOutputs( double[] inputs )
	{
		
		int NoOutputs = perceptrons.length;
		
		double[] out = new double[NoOutputs];
			
	  double thisLayerIn;
		for( int j=0; j<NoOutputs; j++ )
		{
			thisLayerIn = 0.0;
		  //thisLayerIn += perceptrons[j].getBias();
			
		  for( int i=0; i<noInputs; i++)
		  { 			
        thisLayerIn += inputs[i]*perceptrons[j].getWeight( i ); 		  
		  }
		
		  out[j] = outputF( thisLayerIn );
		  
	  }
		return out;
	}
	
	
	/**
	* this is something like WORK!!! a comand to get the outputs of this layer giving the inputs[] for use
	* <br> only with the learn algorithm since stores at the GLERROR the global ERROR
  *
	* No need to override this. If you want to changing the algorithm just override the outputAlgorithm method
	*
	* @param    inputs                   the inputs
	* @returns                           the ouput vector of this layer as an array 
	*/
	public GlobalError GetOutputs( double[] inputs, double shouldOut[] )
	{
		
		double GERROR = 0.0;
		
		int NoOutputs = perceptrons.length;
		
		double[] out = new double[NoOutputs];
			
	  double thisLayerIn = 0.0;
		for( int j=0; j<NoOutputs; j++ )
		{
			thisLayerIn = 0.0;
		  //thisLayerIn += perceptrons[j].getBias();
			
		  for( int i=0; i<noInputs; i++)
		  { 			
        thisLayerIn += inputs[i]*perceptrons[j].getWeight( i ); 		  
		  }
		  
		  out[j] = outputF( thisLayerIn );
		  GERROR +=(shouldOut[j]-out[j])*(shouldOut[j]-out[j]);
	  }		
		return new GlobalError( out, GERROR );
	}
	
		
	/**
	* this is the sigmoid algorithm<br>
	* it can be changed by override it but at this change someone must override and the paragogoOutput method.
	*/
	
	public void findDelta( int i, int j )
	{
	}
	
	/**
	* Here by override you can define the function of non-linearity, default use the sigmoid function
	*/
	private double outputF( double in )
	{
		return (1.0/(1.0 + Math.exp( -in ) )); 
	}
	
	public double[] getDeltaSum( )
	{
		return deltaSum;
	}
	
	private double deltaSum[];
	
	
	
	/**
	* This method iplements the propagation algorithm at the case where the layer is an output layer
  * <p>
	* evaluate and set the new weights at the perceptrons<br>
  * and keeps the delta sums at the an array. These sums can betaken with the getDeltaSum( index ) method
	*	
	*/
	public void learn( double whatCame[], double whatMust[], double[] whatCameIn )
	{
		int NoP = perceptrons.length;
		
		deltaSum = new double[noInputs];
		
		double delta;
		
		//for every neuron ( perceptron )
		for( int i=0; i<NoP; i++ )
		{
			
			//for every weight of this perceptron
			for( int j=0; j<noInputs; j++ )
			{
				//now find the delta of the j weight of i neuron( this works with the sigmoid paragogo)
				delta = ( whatMust[i] - whatCame[i] )*( whatCame[i]*( 1.0 - whatCame[i]) );
				
				//add this delta*newWeight to delta sum
				deltaSum[j] += (delta*perceptrons[i].getWeight( j ));
				
				//set the new weight to perceptron
				perceptrons[i].setWeight( j, perceptrons[i].getWeight(j)+learnRate*delta*whatCameIn[j] );
							  			  
			}
		}
		
	}
	public void setNoInputs( int n ){ noInputs = n; }
	public int getNoInputs( ){ return noInputs; }
	
}