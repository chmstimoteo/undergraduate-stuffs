package nnetwork;

import java.io.Serializable;

public class GlobalError implements Serializable
{
	public double gError;
	public double[]  out;
	public GlobalError( double[] outP, double error )
	{
		out = outP;
		gError=error;
	}
}