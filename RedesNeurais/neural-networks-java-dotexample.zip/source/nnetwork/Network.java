
package nnetwork;

import java.util.Properties;
import java.io.FileInputStream;
import java.io.Serializable;
import java.util.Random;
public class Network implements Serializable
{
	
	HiddenLayer[] layersH;
	InputLayer layerIn;
	OutputLayer layerOut;
	
	private double endGError=0.01;
	
	private final boolean debug = false;
	
	public Network( int PenNoHidden[], int NoOutput, int NoInput, double learnRate, double aproximation )	
	{
	  construct( PenNoHidden, NoOutput, NoInput, learnRate, aproximation );	
	}
	
	private void construct( int PenNoHidden[], int NoOutput, int NoInput, double learnRate, double aproximation )
	{
		layersH = new HiddenLayer[PenNoHidden.length];
		endGError = aproximation;
		
		
		//construct the hiddenLayers
		for( int i=0; i<PenNoHidden.length; i++ )
		{
			if( i==0 )
			  layersH[i] = new HiddenLayer( NoInput, PenNoHidden[i], learnRate );
			else
			  layersH[i] = new HiddenLayer( PenNoHidden[i-1], PenNoHidden[i], learnRate );
		}
		
		//construct the input
		layerIn = new InputLayer( NoInput );
		//and the output
		layerOut = new OutputLayer( PenNoHidden[PenNoHidden.length-1], NoOutput, learnRate );
	}
	
	public Network( String filePath )
	{
		Properties prop = new Properties();
		
		try
		{
			prop.load( new FileInputStream( filePath ) );
			
			int NoHidden = Integer.parseInt( (String)prop.get( "hiddenNo" ) );
			
			int PenNoHidden[] = new int[NoHidden];
			
			for( int i=1; i<NoHidden+1; i++ )
        PenNoHidden[i-1] = Integer.parseInt( (String)prop.get( "hidden"+i ) );
 			
			int NoOut = Integer.parseInt( (String)prop.get( "outputNo" ) );
			int inNo = Integer.parseInt( (String)prop.get( "inputNo" ) );
			double learnRate = Double.parseDouble( (String)prop.get( "learnrate" ) );
			double aprox = Double.parseDouble( (String)prop.get( "aprox" ) );
		  
			construct( PenNoHidden, NoOut, inNo, learnRate, aprox );
		}
		catch( Exception e )
		{
			System.out.println( e );
			System.exit( 0 );
		}
	}
	
	
	public double[] getResults( double[] inputs )
	{		
		int noHL = layersH.length;
		double out[] = inputs;
		
		for( int i=0; i<noHL; i++ )
		{
			out = layersH[i].GetOutputs( out );			
		}
		return layerOut.GetOutputs( out );
	}
		
	
	public void train( Train trains[] )
	{
		Random rand = new Random();
				
		int NoTrains = trains.length;
		
		
		int i = 0;
		while( true )
		{
			train( trains[i].getIn(), trains[i].getOut() );
			i = rand.nextInt(NoTrains);			
		}
		//for( int i=0; i<NoTrains; i++ )      			
	}		
	
	private void print( double[] p, String minima )
	{
		System.out.print("\n"+minima+"\n");
				for( int i=0; i<p.length; i++ )
				{
					System.out.print( p[i]+", " );
				}
	}
	
	private double gError = 0.0;
	/**
	* takes two arguments the ifInputV Vector an what thenOutputV Vector must learn
	* this is the back propagation algorithm
	*/
	public boolean train( double ifInputV[], double thenOutputV[] )
	{	
		//System.out.println( "TRAIN START " );
		//print(ifInputV, "Going to learn if INPUT");
		//print(thenOutputV, "Then Output");
		
		int noHL = layersH.length;
		double out[] = ifInputV; 
		double temp[];
	  
		GlobalError error;
		
		  if( debug )
			  System.out.println( "TRAIN:start" );
			
			out = ifInputV;
				
		//the last is the ouput of the OutputLayer
		ArrayKeeper[] outputs = new ArrayKeeper[noHL];  
		
		for( int i=0; i<noHL; i++ )
		{
			if( debug )
			  System.out.println( "TRAIN:hidden layer ask outs"+i );
				
			out = layersH[i].GetOutputs( out );
			outputs[i] = new ArrayKeeper( out );
			if( debug )
			  System.out.println( "TRAIN:hidden layer GOT outs"+i );
		}		
		if( debug )
			  System.out.println( "TRAIN:output layer ask outs" );
				
		//this return the outs + GERROR		 
		error = layerOut.GetOutputs( out, thenOutputV );
	  				
		if( error.gError < endGError )
		{			
				System.out.println( "should not learn any of these" );
			return false;
		}
		
		out = error.out;	
			if( debug )
			  System.out.println( "TRAIN:output layer GOT outs" );
		
		//now are known all the outputs for every hidden layer is in ouputs and the OuputLayer out is in out
		
			if( debug )
			  System.out.println( "TRAIN:TEach the OutputLayer" );
		//teach the outputLayer
		layerOut.learn( out, thenOutputV, outputs[noHL-1].getArray() );
		
		if( debug )
			  System.out.println( "TRAIN:OUPUT TEACHED" );
		
		
		// know teach every hidden Layer
		for( int i=noHL-1; i>=0; i-- )
		{
			if( debug )
			  System.out.println( "TRAIN:teach the hidden layer "+i );
			if( noHL == 1 )
			{
				layersH[i].learn( outputs[i].getArray(), ifInputV, layerOut.getDeltaSum() );				
				break;
			}	
			
			if( i==(noHL-1) )
			 layersH[i].learn( outputs[i].getArray(), outputs[i-1].getArray(), layerOut.getDeltaSum() );
			else if( i == 0 )			
			  layersH[i].learn( outputs[i].getArray(), ifInputV, layersH[i+1].getDeltaSum() );
			else
			  layersH[i].learn( outputs[i].getArray(), outputs[i-1].getArray(), layersH[i+1].getDeltaSum() );
      
			if( debug )
			  System.out.println( "TRAIN:HIDDEN "+i+" TEACHED" );					
		}
		return true;
	}
	
	
	public class ArrayKeeper
	{
		
		double[] array;
		public ArrayKeeper( double[] arrayToKeep )
		{
			array = arrayToKeep;
		}
		
		public double[] getArray(){ return array; }
		
	}
	
}