
package nnetwork;

import java.util.Random;
import java.io.Serializable;
/**
* This is a Node of the network
*/
public class Perceptron implements Serializable 
{
	private double weights[];
	
	private double bias=1.0;
	
	private double smallwt = 1;
	
	private final boolean debug = true;
	/*public Node()
	{
	} */
	
	public Perceptron( int NoInputs )
	{
		weights = new double[NoInputs];
		
		Random rand = new Random();
		
		try
		{
			if( debug )
				System.out.println( "initalizing a Perceptron..." );
		
		
		  for( int i=0; i<NoInputs; i++)
	    {
				Thread.sleep( 10 );
				rand.setSeed( System.currentTimeMillis() );
			  weights[i] = (2.0 * ( rand.nextDouble() - 0.5 ) * smallwt);
	    } 
			
		
		  bias = 1.0;
		
		}
		catch( Exception e )
		{
			if( debug )
				System.out.println( "Excetiopn initializing a perceptron "+e );
		}
	}
	
	public double getWeight( int index ){ return weights[index]; }
	public void setWeight( int index, double value ){ weights[index] = value; }
	
	public double getBias(){ return bias; }
	
}