#include <sys/types.h>
#include <sys/stat.h>
#include <unistd.h>
#include <stdlib.h>
#include <stdio.h>
#include <fcntl.h>
#include <string.h>

/* Displays the version of the kernel passed as parameter */
int main(int argc, char **argv)
{
  char buffer[80];
  unsigned short offset;
  int fd;
  int r;
  char *ptr;

  if(argc >= 2) {
    fd = open(argv[1], O_RDONLY);
    if(fd < 0) {
      perror("Could not read kernel");
      return 1;
    }
  } else {
    fd = 0;
  }
  if(lseek(fd, 0x20e, SEEK_SET) < 0) {
    perror("Could not seek to version pointer");
    return 1;
  }
  if(read(fd, &offset, 2) < 2) {
    perror("Could not read version pointer");
    return 1;
  }
  if(lseek(fd, offset + 0x200, SEEK_SET) < 0) {
    perror("Could not seek to version string");
    return 1;
  }
  r=read(fd, buffer, 79);
  if(r < 0) {
    perror("Could not read version");
    return 1;
  }
  buffer[r] = '\0';
  ptr = strchr(buffer, ' ');
  if(ptr)
    *ptr='\0';
  printf("%s\n", buffer);
  return 0;
}
