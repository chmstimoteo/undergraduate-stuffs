#ifndef _GNU_SOURCE
#define _GNU_SOURCE
#endif

#include "udpc_dialog.h"
#include "libbb.h"
#include <ftw.h>
#include <string.h>
#include <fcntl.h>
#include <unistd.h>
#include <stdlib.h>

static int isBlock;

static int nodeCreated=0;

static int udev_cb(const char *file, const struct stat *sb, int flag)
{
  char devName[80];
  char devNum[80];
  char *namePtr, *endNamePtr;
  dev_t dev;
  int fd;
  int n; /* bytes read */
  char *eptr;
  int myMajor;
  int myMinor;
  mode_t mode;

  (void)sb;

  /* This is not a file => skip */
  if(flag != FTW_F)
    return 0;

  /* Is this a dev file ? */
  endNamePtr = strrchr(file, '/');
  if(endNamePtr && endNamePtr > file && strcmp(endNamePtr, "/dev"))
    return 0;

  for(namePtr = endNamePtr-1; namePtr > file && *namePtr != '/'; namePtr--);

  strcpy(devName, "/dev/");
  strncat(devName, namePtr, endNamePtr-namePtr);

  fd = open(file, O_RDONLY);
  if(fd < 0)
    return 0;
  n = read(fd, devNum, sizeof(devNum)-1);
  close(fd);
  if(n <= 0)
    return 0;
  devNum[n]='\0';
  myMajor = strtoul(devNum, &eptr, 10);
  myMinor = strtoul(eptr+1, &eptr, 10);
  dev = makedev(myMajor, myMinor);
  if(isBlock)
    mode = S_IFBLK | 0600;
  else 
    mode = S_IFCHR | 0600;
  if(mknod(devName, mode, dev) == 0)
    nodeCreated=1;
  return 0;
}

static char VC[]="/dev/vc";

static void makeTtyLinks(void) {
  /* Backwards compatibility: make links for ttys */
  char i;
  char tty[] = "/dev/tty0";
  char vc[]  = "/dev/vc/0";
  int ret;
  if(udpc_fileExists(VC))
    return; /* Already exists ==> we are using devfs */
  mkdir(VC, 0755);
  for(i='0'; i<'8'; i++) {
    tty[8] = i;
    vc[8] = i;
    ret=symlink(tty, vc);
  }
  mkdir("/dev/floppy", 0644);
  ret=symlink("/dev/fd0", "/dev/floppy/0");
}

int udpc_makeDevices(void)
{
  int r;
  makeTtyLinks();
  isBlock=1;
  nodeCreated=0;
  ftw("/sys/block", udev_cb, 10);
  r = nodeCreated;
  isBlock=0;
  ftw("/sys", udev_cb, 10);
  return r;
}
