#ifndef LANG_H
#define LANG_H

#define TXT_OK 0
#define TXT_CANCEL 1
#define TXT_YES 2
#define TXT_NO 3
#define TXT_CHOOSE_LANGUAGE 4
#define TXT_MENU_KEYMAP 5
#define TXT_LOAD_NET 6
#define TXT_LOAD_DISK_YESNO 7
#define TXT_LOAD_DISK_MODULE 8
#define TXT_INFO_KERNEL 9
#define TXT_INVALID_INPUT 10
#define TXT_INPUT_IPADDR 11
#define TXT_INPUT_NETMASK 12
#define TXT_ENTER_PARAMS 13
#define TXT_ASK_BOOTP 14
#define TXT_SEND_BOOTP 15
#define TXT_ENTER_MODDISK 16
#define TXT_MORE_MODULES 17
#define TXT_START_SENDER 18
#define TXT_START_RECEIVER 19
#define TXT_NO_COMPRESS 20
#define TXT_GZ 21
#define TXT_LZOP 22
#define TXT_UDPCAST_PORT 23
#define TXT_SAVEIT 24
#define TXT_UDPCAST_PORT_MUST_BE_EVEN 25
#define TXT_UDPCAST_PARTITION 26
#define TXT_UDPCAST_PARAMS 27
#define TXT_FILE_NOT_FOUND 28
#define TXT_DISK_NOT_EXIST 29
#define TXT_INVALID_IP 30
#define TXT_INVALID_NETMASK 31
#define TXT_INSERT_CONFIG_FLOPPY 32
#define TXT_SAVEMODE 33

#define EN 0
#define DA 1
#define DE 2
#define FR 3
#define LU 4

extern const char *udpc_msg[5][34];
extern unsigned int udpc_language;
#define MSG(x) (udpc_msg[udpc_language][(x)])

#endif
