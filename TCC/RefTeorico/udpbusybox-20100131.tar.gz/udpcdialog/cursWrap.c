#ifndef _GNU_SOURCE
#define _GNU_SOURCE
#endif
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <stdarg.h>
#include <errno.h>
#include <dirent.h>
#include <sys/klog.h>
#include <ftw.h>
#include <sys/ioctl.h>
#include <linux/fs.h>
#include <stdio.h>

#include "udpc_lang.h"
#include "dialog.h"

void udpc_clearScreen(void) {
  attr_clear (stdscr, LINES, COLS, shadow_attr);
  move(0,0);
  refresh ();
}
