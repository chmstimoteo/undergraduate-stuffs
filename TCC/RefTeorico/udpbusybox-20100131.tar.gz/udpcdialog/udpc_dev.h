#ifndef UDPC_PCI_H
#define UDPC_PCI_H

#include <ftw.h>

typedef struct modules_t {
  /* ====================================================================
   * Which modules correspond to this type of hardware?
   */
  int nPrefixes; /* Number of prefixes corresponding to this hardware */
  const char **prefixes; /* Prefixes accepted for this class of hardware */

  /* ====================================================================
   * Contents of list of choices (at first, only those that correspond to
   * hardware that is present, then a complete list)
   */
  const char **choiceListPtr; /* List of current choices */
  struct moduleChoiceListEntry *choiceList;
  int choiceListSize; /* Size of choice list (currently significative entries) */
  int choiceListTotalSize; /* Size of choice list memory allocation */

  int *pciClasses; /* PCI Devices classes to match against */
  int nPciClasses; /* Number of PCI device classes to match against */

  int *usbClasses; /* USB Devices classes to match against */
  int nUsbClasses; /* Number of USB device classes to match against */

  /* ====================================================================
   * Dialog management
   */
  const char *title; /* Title for dialog boxes */
  int prompt; /* Prompt for name of module */
  int height; /* Height of dialog box */
  int paramPrompt; /* Prompt for module parameters */

  char *modName; /* Pointer where to store module name to? */
  char *modParams; /* Pointer where to store module parameters to? */
  int *modParamIsSet; /* Where to store modParmIsSet flag */

  /* ====================================================================
   * Hardware-specific functions (where disk and net behave differently)
   */
  int (*initFn)(void); /* if this is set, call once at beginning */
  int (*isReadyFn)(void); /* If this is set, and returns 1, exit early */
} modules_t;

int udpc_configureDriver(modules_t *mods, int forceManual, int step);

#endif
