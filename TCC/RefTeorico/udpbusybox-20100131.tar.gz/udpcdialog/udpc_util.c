#ifndef _GNU_SOURCE
#define _GNU_SOURCE
#endif
#include <sys/types.h>
#include <sys/wait.h>
#include <stdio.h>
#include <errno.h>
#include <unistd.h>
#include <stdlib.h>
#include <string.h>
#include <sys/klog.h>
#include <fcntl.h>
#include "udpc_dialog.h"
#include "dialogExt.h"
#include "udpc_lang.h"
#include "libbb.h"

/* Centers a string in buffer. Buffer must be supplied by caller */
char *udpc_centerString(char *buffer, const char *value)
{
  int bufferLength = strlen(buffer);
  int valueLength = strlen(value);

  if(valueLength > bufferLength) {
    strncpy(buffer, value, bufferLength);
  } else {
    int i;
    int startOffset;
    startOffset = (bufferLength - valueLength) / 2;
    for(i=0; i< startOffset; i++)
      buffer[i]=' ';
    strncpy(buffer+i, value, valueLength);
    i+= valueLength;
    for(; i<bufferLength; i++)
      buffer[i]=' ';
  }
  return buffer;
}

/* Find a string in "dialog" entry */
int udpc_findEntry(int nItems, const char * const *items, char *search)
{
  int i;
  for(i=0; i<nItems; i++) {
    if(!strcmp(search, items[2*i])) {
      return i;
    }
  }
  return -1;
}

/**
 * Chose an item from a list
 * needInput   = do we still expect an input?
 * title       = title of the menu box
 * msg         = msg in the menu box
 * height      = total height of box
 * width       = total width of box
 * menu_height = number of menu items displayed at a time
 * item_no     = total number of menu items
 * items       = the menu items
 * keyCol      = column which is being used as a key (0 or 1)
 * value       = string value of choice
 * maxLength   = maximal length of input
 * freeForm    = function to invoke if user wants to enter a freeform parameter
 *
 * Returns:
 *  -1 if error/cancel
 *  the choice's index, otherwise
 *  if freeForm function was used, return whatever freeForm returned
 */
int udpc_choseFromList(int needInput,
		       const char *title, const char *msg, 
		       int height, int width, int menu_height, 
		       unsigned int item_no, const char * const * items,
		       int keyCol, char *value, int maxLength,
		       int (*freeForm)(int))
{
  int r=0;
  if(value[0]) {
    int entries = item_no; /* number of meaningul entries in our choice list */
    if(freeForm)
      entries--;
    r = udpc_findEntry(entries, items+keyCol, value);
    if(r == -1) {
      /* savec choice not found */
      if(freeForm) {
	/* We have a freeform widget: use it. It's always the last of 
	 * the list */
	r = item_no-1;
      } else {
	needInput = 1; /* item not found: prompt user */
	r = 0; /* pre-select 0 */
      }
    }
  } else
    needInput=1;
  if(needInput) {
    r = dialog_menu(title, msg, height, width, menu_height,
		    item_no, items, r);
    dialog_clear();
    if(r<0 || (unsigned int) r >= item_no)
      return -1;
  }
  if(freeForm && (unsigned int)r == item_no-1) {
    return freeForm(needInput);
  } else {
    nt_strncpy(value, items[2*r+keyCol], maxLength);
    return r;
  }
}


#define ERRBUFSIZE 4096
#define THROWSIZE 1024

static char errbuffer[ERRBUFSIZE];

/* Spawns a child process. If executable not found, try busybox */
int udpc_spawn(int in, int out, const char **str) {
  int status;
  int pid;
  int filedes[2];
  int ret;

  if(pipe(filedes) < 0) {
    fprintf(stderr, "Could not make pipe\n");
  }

  switch((pid=fork())) {
  case -1:
    return -1;
  case 0:
    close(filedes[0]);
    close(2);
    ret=dup(filedes[1]);
    close(filedes[1]);

    /* in the child */
    if(in >= 0) { 
      close(0);
      ret=dup(in);
      close(in);
    }
    if(out >=0) {
      close(1);
      ret=dup(out);
      close(out);
    } else {
      /* Copy to stderr */
      close(1);
      ret=dup(2);
    }
    execvp(str[0], (char **)str);
    if(errno == ENOENT)
      execvp("busybox", (char **)str);
    fprintf(stderr, "Could not execute %s (%s)\n", *str, strerror(errno));
    exit(1);
  default:
    close(filedes[1]);
    {
      int n;
      int x;
      char throwAway[THROWSIZE];

      n = full_read(filedes[0], errbuffer, sizeof(errbuffer)-1);
      if(n>0)
	errbuffer[n]='\0';
      else
	errbuffer[0]='\0';
      do {
	x = read(filedes[0], throwAway, sizeof(throwAway));
      } while(x > 0);
      close(filedes[0]);
      waitpid(pid, &status, 0);
    }
  }
  return status;
}

int udpc_display_error(void)
{
  if(errbuffer[0] > 0) {
    udpc_alert("%s", errbuffer);
    return 1;
  } else {
    return 0;
  }
}

int udpc_display_output(void)
{
  if(errbuffer[0] > 0) {
    udpc_info("%s", errbuffer);
    return 1;
  } else {
    return 0;
  }
}


/* Spawns a child process. If executable not found, try busybox */
int udpc_shell_spawn(int in, int out, const char *fmt, ...) 
{
  va_list ap;
  const char *cmd[] = { "sh", "-c", NULL, NULL };
  char buffer[200];
  int r;
  va_start(ap, fmt);
  vsnprintf(buffer, sizeof(buffer)-1, fmt, ap);
  cmd[2]=buffer;
  r= udpc_spawn(in, out, cmd);
  va_end(ap);
  return r;
}


#define FMTBUFSIZE 4096
static char fmtbuffer[FMTBUFSIZE];

#define LINESIZE 77

static int _alert(const char *title,
		  int doPause, int isRed, const char *fmt, va_list ap)
{
  int r;
  unsigned int l = 20;
  int h=5;
  char *ptr;
  vsnprintf(fmtbuffer, FMTBUFSIZE, fmt, ap);


  if(strlen(title)+4 > l)
    l = strlen(title)+4;
  if(strlen(fmtbuffer)+4 > l)
    l = strlen(fmtbuffer)+4;
  if(l > 80) {
    l = 80;
  }

  /* Now, calculate height */
  ptr=fmtbuffer;
  while(*ptr) {
    char *newptr = strchr(ptr, '\n');
    if(newptr == NULL || newptr > ptr+LINESIZE) {
      if(strlen(ptr) < LINESIZE)
	break;
      for(newptr=ptr+LINESIZE-1; newptr != ptr && *newptr != ' ' ; newptr--);
      if(newptr==ptr)
	newptr=ptr+LINESIZE-1;
      else
	*newptr='\n';
    }
    if(h == 24) {
      *newptr = '\0';
      break;
    } else {
      h++;
    }
    ptr = newptr+1;
  }

  if(h > 24)
    h = 24;
  r=dialog_msgbox(title, fmtbuffer, h, l, doPause, isRed);
  dialog_clear();
  return r;
}

void udpc_alert(const char *fmt, ...)
{
  va_list ap;
  va_start(ap, fmt);
  _alert("Alert", 1, 1, fmt, ap);
  va_end(ap);
}

int udpc_info(const char *fmt, ...)
{
  va_list ap;
  int r;
  va_start(ap, fmt);
  r=_alert("Alert", 1, 0, fmt, ap);
  va_end(ap);
  return r;
}

int udpc_msgbox(const char *title, const char *fmt, ...)
{
  va_list ap;
  int r;
  va_start(ap, fmt);
  r=_alert(title, 0, 0, fmt, ap);
  va_end(ap);
  return r;
}

static void udpc_dmsg(const char *title, int isRed, const char *fmt, ...)
{
  va_list ap;
  va_start(ap, fmt);
  _alert(title, 1, isRed, fmt, ap);
  va_end(ap);
}


void udpcd_fatal(const char *fmt, ...)
{
  va_list ap;
  va_start(ap, fmt);
  _alert("Fatal error", 1, 1, fmt, ap);
  va_end(ap);
  end_dialog();
  exit(1);
}

char *udpc_format(int *size, const char *fmt, ...)
{
  va_list ap;
  int l;

  va_start(ap, fmt);
  vsnprintf(fmtbuffer, FMTBUFSIZE, fmt, ap);
  l = strlen(fmtbuffer);
  if(l > *size)
    *size = l;
  return fmtbuffer;
}

void udpc_fileNotFound(const char *filename)
{
    udpc_alert(MSG(TXT_FILE_NOT_FOUND), filename, strerror(errno));
}

void udpc_clearKlog(void)
{
  klogctl(5,0,0);
}

#define KBUFSIZE 4096

int udpc_displayKlog(int isRed)
{
  int n;
  char buffer[KBUFSIZE+1];
  bzero(buffer, KBUFSIZE);
  n = klogctl(3, buffer, KBUFSIZE);
  if(n <= 0)
    return 0; /* error or no kernel message => no log displayed */
  buffer[n] = '\0';
  udpc_dmsg(MSG(TXT_INFO_KERNEL), isRed, "%s", buffer);
  return 1;
}

/**
 * Answers true if file exists, false otherwise
 */
int udpc_fileExists(const char *path) {
  struct stat statb;
  return stat(path, &statb) >= 0;
}

/**
 * Null-terminated strncpy
 */
char *nt_strncpy(char *dest, const char *src, size_t n) {
  char *r=strncpy(dest,src,n);
  if(n > 0)
    dest[n-1]='\0';
  return r;
}

/**
 * Count lines in a file
 */
int udpc_countLines(const char *path) {
  int n=0;
  char buffer[200];
  FILE *f=fopen(path, "r");
  if(f == NULL) {
    udpc_fileNotFound(path);
    return -1;
  }  
  while(fgets(buffer, sizeof(buffer)-1, f))
    n++;
  return n;
}
