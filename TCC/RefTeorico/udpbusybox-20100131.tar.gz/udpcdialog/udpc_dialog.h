#ifndef UDPCDIALOG_H
#define UDPCDIALOG_H

#ifndef USE_DESKTOP
#define USE_DESKTOP(x) /**/
#endif

#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>


#ifdef NO_BB
#define xmalloc malloc
#endif

int udpc_spawn(int in, int out, const char **str);
int udpc_shell_spawn(int in, int out, const char *fmt, ...);
int udpc_display_error(void);
int udpc_display_output(void);

char *udpc_centerString(char *buffer, const char *value);
int udpc_findEntry(int nItems, const char * const *items, char *search);


int udpc_choseFromList(int needInput,
		       const char *title, const char *msg, 
		       int height, int width, int menu_height, 
		       unsigned int item_no, const char * const * items,
		       int keyCol, char *value, int maxLength,
		       int (*freeForm)(int));

void udpc_alert(const char *fmt, ...);
int udpc_info(const char *fmt, ...);
int udpc_msgbox(const char *title, const char *fmt, ...);
void udpcd_fatal(const char *fmt, ...);
char *udpc_format(int *size, const char *fmt, ...);
void udpc_fileNotFound(const char *filename);


void udpc_clearKlog(void);
int udpc_displayKlog(int isRed);

/* User interface configuration */
#define STEP_UI 0x100
extern unsigned int udpc_testMode;
int udpc_uiConfig(int forceManual, int step);

/* Net driver configuration */
#define STEP_NETDRV 0x200
int udpc_configureNetDriver(int forceManual, int step);
int udpc_loadModulesFromFloppy(const char *root);

long long udpc_getMac(const char *ifname, char *ret);

/* IP Address configuration */
#define STEP_NETCFG 0x300
int udpc_configureNetSettings(int forceManual, int step);

/* Disk drivers (SCSI/SATA), if needed */
#define STEP_DISKDRV 0x400
int udpc_configureDiskDriver(int forceManual, int step);

/* Udpcast configuration */
#define STEP_UDPCAST 0x500
int udpc_configureUdpcast(int forceManual, int step);

#define STEP_SAVE 0x600


#define LANGSIZE 10
#define KMAPSIZE 10
#define MODSIZE 20
#define MODPARAMSIZE 60
#define IFNAMESIZE 12
#define DISKNAMESIZE 60
#define MODESIZE 4
#define COMPRSIZE 5
#define UDPCPARAMSIZE 1989

extern struct config {
  int automatic;	/* Automatic setup */

  char language[LANGSIZE];	/* Language of setup program */

  char keymap[KMAPSIZE];	/* Keyboard layout */

  int netAutoconfig;	/* Autoconfigure the network using PCI info */
  char netModule[MODSIZE];	/* Name of network module */
  char netParam[MODPARAMSIZE];	/* Parameter of network module */
  int netParamIsSet;	/* Has the network param been set? */
  char defNic[IFNAMESIZE]; /* Default interface name */

  int enableDiskmodule;		/* Should we enable a disk module? */
  char diskModule[MODSIZE];	/* Name of disk module */
  char diskParam[MODPARAMSIZE];	/* Parameter of disk module */
  int diskParamIsSet;	/* Has the disk param been set? */

  int doDhcp;		/* Configure IP Adress using DHCP */

  struct in_addr ip;	/* IP Address of this node */
  int ipIsSet;		
  struct in_addr netmask;	/* Netmask */
  int netmaskIsSet;	/* Is the netmask set? */


  int port;		/* network port to use */
  int portIsSet;	/* is the port set?*/

  char disk[DISKNAMESIZE];	/* Name of disk where to copy from/to */

  char mode[MODESIZE];	/* Mode: receiver/sender compressed/uncompressed */
  int modeIdx;

  char compr[COMPRSIZE];	/* Mode: receiver/sender compressed/uncompressed */
  int comprIdx;

  char udpcParam[UDPCPARAMSIZE];	/* Additional parameters for UDPCast */
  int udpcParamIsSet;

  char udprParam[UDPCPARAMSIZE];	/* Additional parameters for
					   udp-receiver */
  int udprParamIsSet;

  char udpsParam[UDPCPARAMSIZE];	/* Additional parameters for
					   udp-sender */
  int udpsParamIsSet;

} udpc_config;

#define MENUSIZE(x) sizeof(x)/sizeof(char*)/2
#define MENU(x) MENUSIZE(x),x

extern char yesBuffer[];
extern char noBuffer[];
extern char okBuffer[];
extern char cancelBuffer[];

int udpc_mountFloppy(int alwaysAsk, const char *askMsg);
int udpc_umountFloppy(void);
extern int udpc_haveFloppy;

int udpc_modprobe(const char *module, const char *params);

int udpc_makeDevices(void);
int udpc_fileExists(const char *path);

char *nt_strncpy(char *dest, const char *src, size_t n);

int udpc_countLines(const char *path);

/* const char* getInterface(void);*/
int forAllNetInterfaces(int(*fn)(const char*), int remember);

extern const char defaultIface[];
extern char *iface;

#endif
