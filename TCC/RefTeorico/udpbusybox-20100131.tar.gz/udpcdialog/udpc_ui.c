#ifndef _GNU_SOURCE
#define _GNU_SOURCE
#endif
#include <errno.h>
#include "udpc_dialog.h"
#include "libbb.h"
#include "dialog.h"
#include "udpc_lang.h"
#include "udpc_conffile.h"


unsigned int udpc_language=0;
unsigned int udpc_testMode=0;

static const char *title="GUI Setup";

static const char *languages[] = {
  "US", "English",
  "DA", "Dansk",
  "DE", "Deutsch",
  "FR", "Fran\207ais",
  "LU", "L\211tzebuerg\211sch",
};

static const char *keymaps[] = {
  "US",	"United States",
  "SG", "Swiss German",
  "BE", "Belgian",
  "FR", "French",
  "DE", "German"
};

char yesBuffer[]    ="     ";
char noBuffer[]     ="     ";
char okBuffer[]     ="      ";
char cancelBuffer[] ="      ";


static void udpc_initDialogue(void)
{
  udpc_centerString(yesBuffer,MSG(TXT_YES));
  udpc_centerString(noBuffer,MSG(TXT_NO));

  udpc_centerString(okBuffer,MSG(TXT_OK));
  udpc_centerString(cancelBuffer,MSG(TXT_CANCEL));
}


static int setLanguage(int forceManual)
{
  int r;
  if(udpc_config.automatic != 1)
    forceManual=1;
  r=udpc_findEntry(MENU(languages), udpc_config.language);
  if(r==-1) {
    forceManual=1;
    udpc_language=0;
  } else {
    udpc_language=r;
  }
  udpc_initDialogue();

  r=udpc_choseFromList(forceManual,
		       title, MSG(TXT_CHOOSE_LANGUAGE),
		       20, 30, 10, MENU(languages),
		       0, 
		       udpc_config.language, sizeof(udpc_config.language),
		       NULL);
  if(r < 0)
    return -1;
  udpc_language=r;
  udpc_initDialogue();
  return 0;
}

/* ======================================================
 * Setting of the keymap
 * ====================================================== */
static const char *loadkmap_cmd[] = { "loadkmap", NULL };

static int setKeymap(int needInput)
{
  while(1) {
    int r=udpc_choseFromList(needInput,
			     title, MSG(TXT_MENU_KEYMAP),
			     20, 30, 10, MENU(keymaps), 0, 
			     udpc_config.keymap, sizeof(udpc_config.keymap),
			     NULL);
    if(r < 0)
      return -1;
    if(!udpc_testMode) {
      char filename[] = "/keymaps/XX.bkm";
      int f;
      filename[9] = udpc_config.keymap[0];
      filename[10] = udpc_config.keymap[1];
      f = open(filename, O_RDONLY);
      if(f < 0) {
	udpc_fileNotFound(filename);
      } else {
	if(!udpc_testMode && udpc_spawn(f, -1, loadkmap_cmd)) {
	  close(f);
	  udpc_display_error();
	} else {
	  close(f);
	  return 0;
	}
      }
    }
    needInput=1;
  }
}

int udpc_uiConfig(int forceManual, int step)
{
  udpc_initDialogue();

  while(1) {
    switch(step) {
    case STEP_UI + 1:
      if(setLanguage(forceManual) < 0) {
	return -1;
      } else {
	step++;
      }
      break;

    case STEP_UI + 2:
      if(setKeymap(forceManual) < 0) {
	step--;
	forceManual=1;
	break;
      } else {
	return 0;
      }

    case STEP_UI + 0xff:
      step = STEP_UI + 2;
      break;
    }
  }
}
