/*
 *  inputbox.c -- implements the input box
 *
 *  AUTHOR: Savio Lam (lam836@cs.cuhk.hk)
 *
 *  This program is free software; you can redistribute it and/or
 *  modify it under the terms of the GNU General Public License
 *  as published by the Free Software Foundation; either version 2
 *  of the License, or (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */

#ifndef _GNU_SOURCE
#define _GNU_SOURCE
#endif
#include "dialog.h"
#include "udpc_dialog.h"

char dialog_input_result[MAX_LEN + 1];

struct state {
  int box_x;
  int box_y;
  int box_width;
  int scroll;
  int input_x;
  char *instring;
  WINDOW *dialog;
};

/* Sets the cursor to the given position and optionnally refresh
 * pos=-1 means current input_x position
 */
static void setCursor(struct state *state)
{
    wmove (state->dialog, state->box_y, state->box_x+state->input_x);
    wrefresh (state->dialog);
}


/* Redisplays the window state between startPos and endPos.
 * To be invoked for instance after scrolling */
static int redisplay(struct state *state, int startPos, int endPos)
{
  int i;
  int strLen = strlen(state->instring);
  if(startPos < 0)
      startPos = 0;
  wmove (state->dialog, state->box_y, state->box_x+startPos);

  /* -2 means redisplay until end of string plus 1 */
  if(endPos == -2)
      endPos = strLen + 1 - state->scroll;

  /* if endpos out of range, go until the end of box */
  if(endPos < 0 || endPos > state->box_width)
    endPos = state->box_width;

  for (i = startPos; i < endPos; i++)
    waddch (state->dialog, state->scroll + i < strLen ?
	    state->instring[state->scroll + i] : ' ');
  setCursor(state);
  return 0;
}

/* Move cursor one step left, and trigger a scroll if necessary */
static void cursorLeft(struct state *state, int doRedisplay)
{
    if(state->input_x == 0) {
	/* At left border; scroll */

	int newScroll;
	newScroll = state->scroll < state->box_width - 1 ?
	    0 : state->scroll - (state->box_width - 1);
	state->input_x += state->scroll - newScroll - 1;
	state->scroll=newScroll;
	redisplay(state, 0, -2);
    } else {
	state->input_x--;
	if(doRedisplay)
	    redisplay(state, state->input_x,-2);
	else
	    setCursor(state);
    } 
}

static void cursorRight(struct state *state, int doRedisplay)
{
    if(state->input_x == state->box_width - 1) {
	state->scroll++;
	redisplay(state, 0, -2);
    } else {
	state->input_x++;
	if(doRedisplay)
	    redisplay(state, state->input_x-1,-2);
	else
	    setCursor(state);
    }
}

/*
 * Display a dialog box for inputing a string
 */
int
dialog_inputbox (const char *title, const char *prompt, int height, int width,
		 const char *init)
{
    struct state state;
    int i, x, y;
    int key = 0, button = -1;
    int strLen;

    state.instring = dialog_input_result;
    state.scroll = 0;
    state.input_x = 0;

    /* center dialog box on screen */
    x = (COLS - width) / 2;
    y = (LINES - height) / 2;

#ifdef HAVE_NCURSES
    if (use_shadow)
	draw_shadow (stdscr, y, x, height, width);
#endif
    state.dialog = newwin (height, width, y, x);
    keypad (state.dialog, TRUE);

    draw_box (state.dialog, 0, 0, height, width, dialog_attr, border_attr);
    wattrset (state.dialog, border_attr);
    wmove (state.dialog, height - 3, 0);
    waddch (state.dialog, ACS_LTEE);
    for (i = 0; i < width - 2; i++)
	waddch (state.dialog, ACS_HLINE);
    wattrset (state.dialog, dialog_attr);
    waddch (state.dialog, ACS_RTEE);
    wmove (state.dialog, height - 2, 1);
    for (i = 0; i < width - 2; i++)
	waddch (state.dialog, ' ');

    if (title != NULL) {
	wattrset (state.dialog, title_attr);
	wmove (state.dialog, 0, (width - strlen (title)) / 2 - 1);
	waddch (state.dialog, ' ');
	waddstr (state.dialog, title);
	waddch (state.dialog, ' ');
    }
    wattrset (state.dialog, dialog_attr);
    print_autowrap (state.dialog, prompt, width - 2, 1, 3);

    /* Draw the input field box */
    state.box_width = width - 6;
    getyx (state.dialog, y, x);
    state.box_y = y + 2;
    state.box_x = (width - state.box_width) / 2;
    draw_box (state.dialog, y + 1, state.box_x - 1, 3, state.box_width + 2,
	      border_attr, dialog_attr);

    x = width / 2 - 11;
    y = height - 2;
    print_button (state.dialog, cancelBuffer, y, x + 14, FALSE);
    print_button (state.dialog, okBuffer, y, x, TRUE);

    /* Set up the initial value */
    wmove (state.dialog, state.box_y, state.box_x);
    wattrset (state.dialog, inputbox_attr);
    if (!init)
	state.instring[0] = '\0';
    else
	strcpy (state.instring, init);
    state.input_x = strlen (state.instring);
	
    if (state.input_x >= state.box_width) {
	state.scroll = state.input_x - state.box_width + 1;
	state.input_x = state.box_width - 1;
    }
    redisplay(&state, 0, -1);

    while (key != ESC) {
	key = wgetch (state.dialog);
	strLen=strlen(state.instring);
	if (button == -1) {	/* Input box selected */
	    switch (key) {
	    case TAB:
	    case KEY_UP:
	    case KEY_DOWN:
	    case M_EVENT + 'i':
	    case M_EVENT + 'o':
	    case M_EVENT + 'c':
		break;

	    case 1:
	    case KEY_HOME:
		if(state.input_x) {
		    /* we are in the middle of the display. First jump
		     * to beginning of display before scrolling */
		    state.input_x = 0;
		    setCursor(&state);
		} else {
		    /* we are at the beginning of the display, scroll at
		     * the beginning of the string */
		    state.scroll=0;
		    redisplay(&state, 0, -2);
		}
		break;

	    case 5:
	    case KEY_END:
		if(state.input_x < state.box_width-1) {
		    /* We are not yet at the end. Jump til the end */
		    if(state.scroll + state.box_width-1 > strLen)
			state.input_x = strLen - state.scroll;
		    else
			state.input_x = state.box_width-1;
		    setCursor(&state);
		} else {
		    /* we are at the end of the display. Jump til the end
		     * of the string */
		    state.input_x = state.box_width-1;
		    state.scroll = strLen - state.input_x;
		    redisplay(&state, 0, -2);
		}
		break;

	    case 11: /* Control-K */
	    case KEY_EOL:
		state.instring[state.input_x+state.scroll] = '\0';
		redisplay(&state, 0, -1);
		break;

	    case KEY_LEFT:
		if(state.input_x || state.scroll)
		    cursorLeft(&state, 0);
		continue;
	    case KEY_RIGHT:
		if(state.instring[state.input_x + state.scroll])
		    cursorRight(&state, 0);
		continue;

	    case KEY_DC:
		memmove(state.instring+state.input_x+state.scroll,
			state.instring+state.input_x+state.scroll+1,
			strLen-state.input_x+state.scroll);
		redisplay(&state, 0, -2);
		break;

	    case KEY_BACKSPACE:
	    case 127:
		if (state.input_x || state.scroll) {
		    memmove(state.instring+state.input_x+state.scroll-1,
			    state.instring+state.input_x+state.scroll,
			    strLen-state.input_x+state.scroll+1);

		    wattrset (state.dialog, inputbox_attr);
		    cursorLeft(&state, 1);
		}
		continue;
	    default:
		if (key < 0x100 && isprint (key)) {
		    if (state.scroll + state.input_x < MAX_LEN) {

			/* Move rest of string to make space */
			memmove(state.instring+state.scroll+state.input_x+1,
				state.instring+state.scroll+state.input_x,
				strLen+1-state.scroll-state.input_x);

			wattrset (state.dialog, inputbox_attr);
			state.instring[state.scroll + state.input_x] = key;
			cursorRight(&state, 1);
		    } else
			flash ();	/* Alarm user about overflow */
		    continue;
		}
	    }
	}
	switch (key) {
	case 'O':
	case 'o':
	    delwin (state.dialog);
	    return 0;
	case 'C':
	case 'c':
	    delwin (state.dialog);
	    return 1;
	case M_EVENT + 'i':	/* mouse enter events */
	case M_EVENT + 'o':	/* use the code for 'UP' */
	case M_EVENT + 'c':
	    button = (key == M_EVENT + 'o') - (key == M_EVENT + 'c');
	case KEY_UP:
	case KEY_LEFT:
	    switch (button) {
	    case -1:
		button = 1;	/* Indicates "Cancel" button is selected */
		print_button (state.dialog, okBuffer, y, x, FALSE);
		print_button (state.dialog, cancelBuffer, y, x + 14, TRUE);
		wrefresh (state.dialog);
		break;
	    case 0:
		button = -1;	/* Indicates input box is selected */
		print_button (state.dialog, cancelBuffer, y, x + 14, FALSE);
		print_button (state.dialog, okBuffer, y, x, TRUE);
		wmove (state.dialog, state.box_y, state.box_x + state.input_x);
		wrefresh (state.dialog);
		break;
	    case 1:
		button = 0;	/* Indicates "OK" button is selected */
		print_button (state.dialog, cancelBuffer, y, x + 14, FALSE);
		print_button (state.dialog, okBuffer, y, x, TRUE);
		wrefresh (state.dialog);
		break;
	    }
	    break;
	case TAB:
	case KEY_DOWN:
	case KEY_RIGHT:
	    switch (button) {
	    case -1:
		button = 0;	/* Indicates "OK" button is selected */
		print_button (state.dialog, cancelBuffer, y, x + 14, FALSE);
		print_button (state.dialog, okBuffer, y, x, TRUE);
		wrefresh (state.dialog);
		break;
	    case 0:
		button = 1;	/* Indicates "Cancel" button is selected */
		print_button (state.dialog, okBuffer, y, x, FALSE);
		print_button (state.dialog, cancelBuffer, y, x + 14, TRUE);
		wrefresh (state.dialog);
		break;
	    case 1:
		button = -1;	/* Indicates input box is selected */
		print_button (state.dialog, cancelBuffer, y, x + 14, FALSE);
		print_button (state.dialog, okBuffer, y, x, TRUE);
		wmove (state.dialog, state.box_y, state.box_x + state.input_x);
		wrefresh (state.dialog);
		break;
	    }
	    break;
	case ' ':
	case '\n':
	    delwin (state.dialog);
	    return (button == -1 ? 0 : button);
	case ESC:
	    break;
	}
    }

    delwin (state.dialog);
    return -1;			/* ESC pressed */
}
