#ifndef UDPC_CONFFILE_H
#define UDPC_CONFFILE_H

#define TYPE_INTEGER 1
#define TYPE_BOOLEAN 2
#define TYPE_STRING 3
#define TYPE_NONNULL_STRING 4
#define TYPE_IP 5

#ifndef offsetof
# define offsetof(TYPE, MEMBER) ((size_t) &((TYPE *)0)->MEMBER)
#endif


struct configDesc {
  const char *name;
  int type;
  int length;
  int offset;
  int flagOffset;
};

int udpc_loadConfig(const char *file, void *data, struct configDesc *desc,
		    int doOverwrite);
int udpc_loadConfigEnv(void *data, struct configDesc *desc,int doOverwrite);
int udpc_saveConfig(const char *file, void *data, struct configDesc *desc);
int udpc_clearConfig(void *data, struct configDesc *desc);

#endif
