#ifndef DIALOG_EXT_H
#define DIALOG_EXT_H

int dialog_yesno (const char *title, const char *prompt, int height, int width,
		  int defaultValue);
int dialog_msgbox (const char *title, const char *prompt, int height,
		int width, int pausee, int isRed);
int dialog_textbox (const char *title, const char *file, int height, int width);
int dialog_menu (const char *title, const char *prompt, int height, int width,
		int menu_height, int item_no, const char * const * items,
		 int preselect);
int dialog_checklist (const char *title, const char *prompt, int height,
		int width, int list_height, int item_no,
		const char * const * items, int flag, int separate_output);
extern char dialog_input_result[];
extern unsigned char dialog_file_result[];
int dialog_inputbox (const char *title, const char *prompt, int height,
		int width, const char *init);
int dialog_guage (const char *title, const char *prompt, int height, int width,
		int percent);

int dialog_file( const char *title, const char *prompt, int height, int width, int mode, const char *init);

void dialog_clear (void);

void udpc_clearScreen(void);

void init_dialog (void);
void end_dialog (void);

#endif
