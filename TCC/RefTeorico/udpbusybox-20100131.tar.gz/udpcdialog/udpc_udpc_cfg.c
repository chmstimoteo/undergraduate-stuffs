#ifndef _GNU_SOURCE
#define _GNU_SOURCE
#endif
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <stdarg.h>
#include <errno.h>
#include <dirent.h>
#include <ftw.h>
#include <linux/hdreg.h>
#include <sys/ioctl.h>

#include "udpc_dialog.h"
#include "libbb.h"
#include "dialog.h"
#include "udpc_lang.h"
#include "udpc_conffile.h"

/* ===============================================================
 * Setup of Udpcast itself
 * =============================================================== */

static const char *title = "Udpcast config";

/* Input of udpcast port parameter */
static int configurePort(int needInput)
{
  char buffer[40]="";
  int port=0;

  if(!udpc_config.portIsSet)
    needInput=1;
  if(udpc_config.portIsSet) {
    sprintf(buffer, "%d", udpc_config.port);
    port = udpc_config.port;
  } else {
    strcpy(buffer, "9000");
  }
  while(1) {
    if(!needInput) {
      if(port % 2) {
	udpc_alert(MSG(TXT_UDPCAST_PORT_MUST_BE_EVEN));
	dialog_clear();
      } else {
	udpc_config.port = port;
	udpc_config.portIsSet = 1;
	dialog_clear();
	return 0;
      }
    }
    if(dialog_inputbox(title, MSG(TXT_UDPCAST_PORT), 10, 40, buffer)) {
      dialog_clear();
      return -1;
    }
    if(dialog_input_result[0]) {
      needInput=0;
      port = strtol(dialog_input_result,0,0);
    } else {
      needInput=1;
    }
  }
}


#define MAX_DISKS 200

static unsigned int diskIdx;
static struct diskName {
  char name[11];
} *diskNames=NULL;

static const char **diskPtr;


static int registerDiskCb(const char *path, const struct stat *sb, int flag)
{
  struct stat buf;
  (void) flag;
  if(stat(path, &buf) >= 0 &&
     S_ISBLK(buf.st_mode) &&
     major(sb->st_rdev) != 1 && 
     major(sb->st_rdev) != 2) {
    diskPtr[2*diskIdx]=" ";
    diskPtr[2*diskIdx+1]=strdup(path);    
    diskIdx++;
  }
  return 0;
}

static int makeDiskNodes(void)
{
  if(diskPtr == NULL) {
    diskPtr = (const char **) xmalloc(2*(MAX_DISKS+1)*sizeof(char*));
    diskNames = 
      (struct diskName *) xmalloc(MAX_DISKS * sizeof(struct diskName));
    diskIdx=0;
    if(diskIdx == 0) {
      udpc_makeDevices();
      ftw("/dev", registerDiskCb, 10);
    }
    diskPtr[2*diskIdx] = " ";
    diskPtr[2*diskIdx+1] = "OTHER";
  }
  return 0;
}

/* Input of disk name */
static int inputDiskName(int needInput)
{
  makeDiskNodes();
  if(!udpc_config.disk[0])
    needInput=1;

  while(1) {
    int r;
    if(!needInput && udpc_config.disk[0]) {
      if(!udpc_fileExists(udpc_config.disk)) {
	udpc_alert(MSG(TXT_DISK_NOT_EXIST), udpc_config.disk, 
		   strerror(errno));
	dialog_clear();
      } else {
	dialog_clear();
	return 0;
      }
    }

    r=dialog_inputbox(title, MSG(TXT_UDPCAST_PARTITION),
		      10, 40, udpc_config.disk);
    if(r) {
      dialog_clear();
      return -1;
    }
    nt_strncpy(udpc_config.disk, dialog_input_result, DISKNAMESIZE);
    needInput = 0;
  }
}


static int choseDisk(int needInput)
{
  makeDiskNodes();
  if(!udpc_config.disk[0])
    needInput=1;
  if(!needInput && udpc_fileExists(udpc_config.disk))
    return 0;
  return udpc_choseFromList(needInput, title, MSG(TXT_UDPCAST_PARTITION), 
			    23, 45, 16, 
			    diskIdx+1, diskPtr, 1,
			    udpc_config.disk, DISKNAMESIZE,
			    inputDiskName);
}


static int enterUdpcastMode(int forceManual)
{
  int r;
  const char *choices[12] = { "rcv", 0, "snd", 0 };
  choices[1] = MSG(TXT_START_RECEIVER);
  choices[3] = MSG(TXT_START_SENDER);

  r=udpc_choseFromList(forceManual,
		       title, "Udpcast Mode",
		       14, 70, 2, 
		       2,choices,
		       0, udpc_config.mode, sizeof(udpc_config.mode),
		       NULL);
  if(r < 0)
    return r;
  udpc_config.modeIdx = r;
  return 0;
}

static int enterUdpcastCompressionMode(int forceManual)
{
  int r;
  const char *choices[6] = { "none", 0, "gz", 0, "lzop", 0 };
  choices[1] = MSG(TXT_NO_COMPRESS);
  choices[3] = MSG(TXT_GZ);
  choices[5] = MSG(TXT_LZOP);

  r=udpc_choseFromList(forceManual,
		       title, "Udpcast Compresion",
		       14, 70, 3, 
		       3,choices,
		       0, udpc_config.compr, sizeof(udpc_config.compr),
		       NULL);
  if(r < 0)
    return r;
  udpc_config.comprIdx = r;
  return 0;
}

/* Input of udpcast parameters */
static int enterUdpcastParams(int forceManual)
{
  int r;
  if(udpc_config.udpcParamIsSet && !forceManual)
    return 0;
  r=dialog_inputbox(title, MSG(TXT_UDPCAST_PARAMS),
		    10, 40, udpc_config.udpcParam);
  dialog_clear();
  if(r)
    return r;
  nt_strncpy(udpc_config.udpcParam, dialog_input_result, UDPCPARAMSIZE);
  udpc_config.udpcParamIsSet=1;
  return 0;
}

static int configureDisk(void)
{
  char *disk = strdup(udpc_config.disk);
  int i,d;
  
  for(i=strlen(disk)-1; i >= 0 && disk[i] >= '0' && disk[i] <= '9'; i--) {    
  }
  disk[i+1]='\0';
  d = open(disk, O_RDONLY);
  if(d < 0) {
    /* Do not raise an error => this may simply mean that this is not a
       standard SCSI or IDE disk, and its partitions are simply following a
       different naming convention */
    free(disk);
    return 0;
  }

  /* FIXME: should only do this if it is an IDE disk */
  ioctl(d, HDIO_SET_DMA, 1);
  ioctl(d, HDIO_SET_UNMASKINTR, 1);
  ioctl(d, HDIO_SET_32BIT, 1);
  ioctl(d, HDIO_SET_MULTCOUNT, 16);

  free(disk);
  return 0;
}

int udpc_configureUdpcast(int forceManual, int step)
{
  if(udpc_config.automatic != 1)
    forceManual=1;
  while(1) {
    switch(step) {

    case STEP_UDPCAST + 1:
      if(configurePort(forceManual) < 0)
	return -1;
      step = STEP_UDPCAST + 2;
      break;

    case STEP_UDPCAST + 2:
      if(choseDisk(forceManual) < 0 ||
	 configureDisk() < 0) {
	step--;
	forceManual = 1;
      } else
	step++;
      break;
      
    case STEP_UDPCAST + 3:
      if(enterUdpcastParams(forceManual)) {
	step--;
	forceManual=1;
      } else {
	step++;
      }
      break;

    case STEP_UDPCAST + 4:
      if(enterUdpcastCompressionMode(forceManual) < 0) {
	step--;
	forceManual=1;
      } else {
	step++;
      }      
      break;

    case STEP_UDPCAST + 5:
      if(enterUdpcastMode(forceManual) < 0) {
	step--;
	forceManual=1;
      } else {
	return 0;
      }
      break;


    case STEP_UDPCAST + 0xff:
      step = STEP_UDPCAST + 5;
      break;
    }
  }
}
