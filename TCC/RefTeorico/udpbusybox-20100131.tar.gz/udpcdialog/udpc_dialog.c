#ifndef _GNU_SOURCE
#define _GNU_SOURCE
#endif
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <stdarg.h>
#include <errno.h>
#include <dirent.h>
#include <sys/klog.h>
#include <ftw.h>
#include <sys/ioctl.h>
/* #include <linux/fs.h>*/
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <fcntl.h>
#include <string.h>
#include "dialogExt.h"

#include "udpc_lang.h"
#include "udpc_dialog.h"
#include "udpc_conffile.h"
#include "libbb.h"

struct config udpc_config;

struct configDesc desc[]= {
  { "auto", TYPE_BOOLEAN,	-1, offsetof(struct config, automatic), -1 },
  { "lang", TYPE_NONNULL_STRING,	LANGSIZE, 
    offsetof(struct config, language), -1 },
  { "kbmap", TYPE_NONNULL_STRING,	KMAPSIZE, 
    offsetof(struct config, keymap), -1 },

  { "netauto", TYPE_BOOLEAN,	-1, offsetof(struct config, netAutoconfig), -1 },
  { "netmodule", TYPE_NONNULL_STRING,	MODSIZE,
    offsetof(struct config,netModule), -1},
  { "netmodparm", TYPE_STRING,	MODPARAMSIZE,
    offsetof(struct config, netParam),offsetof(struct config, netParamIsSet)},
  { "defNic", TYPE_STRING,	IFNAMESIZE,
    offsetof(struct config, defNic), -1},

  { "enableDiskmodule", TYPE_BOOLEAN,	-1, offsetof(struct config, enableDiskmodule), -1 },

  { "diskmodule", TYPE_NONNULL_STRING,	MODSIZE,
    offsetof(struct config,diskModule), -1},
  { "diskmodparm", TYPE_STRING,	MODPARAMSIZE,
    offsetof(struct config, diskParam),offsetof(struct config, diskParamIsSet)},

  { "dhcp", TYPE_BOOLEAN,	-1, offsetof(struct config, doDhcp), -1 },

  { "ip", TYPE_IP,	-1, 
    offsetof(struct config, ip), offsetof(struct config, ipIsSet)},
  { "netmask", TYPE_IP,	-1, 
    offsetof(struct config, netmask), offsetof(struct config, netmaskIsSet)},

  { "port", TYPE_INTEGER,	-1, 
    offsetof(struct config, port), offsetof(struct config, portIsSet)},

  { "disk", TYPE_NONNULL_STRING,	DISKNAMESIZE, 
    offsetof(struct config, disk), -1},

  { "umode", TYPE_NONNULL_STRING,	MODESIZE, 
    offsetof(struct config, mode), -1},

  { "compr", TYPE_NONNULL_STRING,	COMPRSIZE, 
    offsetof(struct config, compr), -1},

  { "udpcparam", TYPE_STRING,	UDPCPARAMSIZE, 
    offsetof(struct config, udpcParam), offsetof(struct config, udpcParamIsSet)},
  { "udprparam", TYPE_STRING,	UDPCPARAMSIZE, 
    offsetof(struct config, udprParam), offsetof(struct config, udprParamIsSet)},
  { "udpsparam", TYPE_STRING,	UDPCPARAMSIZE, 
    offsetof(struct config, udpsParam), offsetof(struct config, udpsParamIsSet)},

  { NULL, -1, -1, -1, -1 }
};

int udpc_haveFloppy=0; /* Do we have a floppy drive? */
int udpc_haveCd=0; /* Do we have a CD drive? */



#if 0
/*static char *tar_cmd[] = { "tar", "xvf", "-", NULL };*/
static char *tar_cmd[] = { "sh", "-c", "echo zoo ; exec tar xvf - 2>&1", NULL };

static int untarFd(int fd)
{
  return udpc_spawn(fd, 2, tar_cmd);
}

static int untarRootAdd(void)
{
  struct statfs sfs;
  int r, fd;
  unsigned int size;
  r = statfs("/", &sfs);
  if(r < 0) {
    bb_perror_msg("statfs error");
    return -1;
  }
  fd = open("/dev/rd/0", O_RDONLY);
  if(fd < 0) {
    bb_perror_msg("Could not open initrd");
    return -1;
  }
  r = ioctl(fd, BLKGETSIZE, &size);
  fprintf(stderr, "Fs size=%ld   Rd size=%d\n", sfs.f_blocks, size);
  if(lseek(fd, sfs.f_blocks*1024, SEEK_SET) < 0) {
    bb_perror_msg("Could not seek");
    return -1;
  }
  r=untarFd(fd);
  fprintf(stderr, "Tar returned %x\n", r);
  return 0;
}
#endif

static const char *mount_floppy_cmd[] = { "mount", "/floppy", NULL };

static int floppyChanged=0;

/* Mounts the floppy, asking the user to insert it if necessary 
 * if askMsg is set, asks user to insert floppy if necessary (no floppy
 * present)
 * if alwaysask is set, always ask, even if a floppy is in drive
 * Returns -2 if user cancelled
 *         -1 if floppy could not be mounted
 */
int udpc_mountFloppy(int alwaysAsk, const char *askMsg)
{
  int r;
  if(alwaysAsk)
    floppyChanged=1;
  while(1) {
    if(alwaysAsk) {
      r = udpc_info(askMsg);
      if(r)
	return -2;
    }
    r = udpc_spawn(-1, -1, mount_floppy_cmd);
    if(r == 0) {
      /* success ! */
      return 0;
    }
    if(!askMsg) {
      return -1;
    }
    if(alwaysAsk) {
      /* display the error */
      udpc_display_error();
    }
    alwaysAsk=1;
  }
}

static const char *umount_floppy_cmd[] = { "umount", "/floppy", NULL };

int udpc_umountFloppy(void)
{
  return udpc_spawn(-1, -1, umount_floppy_cmd);
}

static const char *mount_cd_cmd[] = { "mount", "/cd", NULL };

static int udpc_mountCd(void)
{
  /* we don't prompt for CD: the one that we booted from is sufficiently
   * large to contain everything we might ever need */
  return udpc_spawn(-1, -1, mount_cd_cmd);
}

static const char *umount_cd_cmd[] = { "umount", "/cd", NULL };

static int udpc_umountCd(void)
{
  return udpc_spawn(-1, -1, umount_cd_cmd);
}

static int askSaveFile(void)
{
  int r;
  int saveMode=0; /* should we also save the mode ? */

  /* if we don't have a floppy drive, don't attempt to save config: */
  if(!udpc_haveFloppy)
    return 0;

  while(1) {
    r = dialog_yesno(MSG(TXT_SAVEIT), MSG(TXT_SAVEIT), 5, 50, !0);
    dialog_clear();
    if(r < 0)
      return -1;
    if(r)
      return 0; /* No save requested */
    r = dialog_yesno(MSG(TXT_SAVEIT), MSG(TXT_SAVEMODE), 5, 70, !0);
    dialog_clear();
    if(r < 0)
      continue;
    saveMode = !r;

    udpc_config.automatic=1;
    r = udpc_mountFloppy(floppyChanged, MSG(TXT_INSERT_CONFIG_FLOPPY));
    if(r)
      continue;
    if(!saveMode) {
      udpc_config.mode[0] = '\0';
    }
    udpc_saveConfig("/floppy/udpcfg.txt", &udpc_config, desc);
    udpc_umountFloppy();
    return 0;
  }
}

/* ===============================================================
 * Main function
 * =============================================================== */

static int mainDialog(void)
{
  int forceManual = 0;
  int step = STEP_UI + 1;
  if(udpc_config.automatic != 1)
    forceManual=1;

  while(1) {
    switch(step & 0xff00) {
    case STEP_UI:
      if(udpc_uiConfig(forceManual, step) < 0) {
	udpc_alert(MSG(TXT_INVALID_INPUT));
      } else
	step = STEP_NETDRV+1;
      break;

    case STEP_NETDRV:
      if(udpc_configureNetDriver(forceManual, step) < 0) {
	forceManual = 1;
	step = STEP_UI+0xff;
      } else {
	step = STEP_NETCFG + 1;
      }
      break;

    case STEP_NETCFG:
      if(udpc_configureNetSettings(forceManual, step) < 0) {
	forceManual = 1;
	step = STEP_NETDRV+0xff;
      } else {
	step = STEP_DISKDRV+1;
      }
      break;

    case STEP_DISKDRV:
      if(udpc_configureDiskDriver(forceManual, step) < 0) {
	forceManual = 1;
	step = STEP_NETCFG+0xff;
      } else {
	step = STEP_UDPCAST+1;
      }
      break;

    case STEP_UDPCAST:
      if(udpc_configureUdpcast(forceManual, step) < 0) {
	forceManual = 1;
	step = STEP_DISKDRV+0xff;
      } else {
	step = STEP_SAVE+1;
      }
      break;

    case STEP_SAVE:
      if(forceManual && askSaveFile() < 0) {
	step = STEP_UDPCAST+0xff;
      } else {
	/* Clear the screen */
	udpc_clearScreen();
	return 0;
      }
      break;
    }
  }
}

static void set_parm(const char *file, int value)
{
    int fd;
    fd = open(file, O_WRONLY);
    if(fd < 0) {
	fprintf(stderr, "Could not open %s (%s)\n", file, strerror(errno));
	return;
    }
    dprintf(fd, "%d", value);
    close(fd);
}

int udpc_modprobe(const char *module, const char *params)
{
    return udpc_shell_spawn(-1, -1, "modprobe %s %s", module, params);
}

static const char *cmd[] = { "udp-receiver", "udp-sender" };

static const char *compr[] = {
  "",
  " -p gunzip",
  " -p 'lzop -d'",
  "",
  " -p gzip",
  " -p lzop",
};

static const char *floppyModules[] = {
    "floppy", "nls_cp437","nls_iso8859-1", "vfat"
};

static int systemf(int onlyIfExists, const char *fmt, ...)
  __attribute__ ((format (printf, 2, 3)));
static int systemf(int onlyIfExists, const char *fmt, ...) {
  va_list ap;
  char ch;
  int size;
  int ret;

  va_start(ap, fmt);
  size=vsnprintf(&ch, 1, fmt, ap);
  if(size >= 0) {
    char *bigbuf = alloca(size+1);
    struct stat statBuf;
    char *end;
    vsnprintf(bigbuf, size+1, fmt, ap);
    end = strchr(bigbuf, ' ');
    if(end) {
      *end='\0';
    }
    if(onlyIfExists && stat(bigbuf, &statBuf) < 0) {
      ret=0;
    } else {
      if(end)
	*end=' ';
      ret=system(bigbuf);
    }
  } else {
    ret=-1;
  }
  va_end(ap);
  return ret;
}

#ifndef NO_BB
void _IO_cleanup(void);
static const void *__elf_set___libc_atexit_element__IO_cleanup__ 
__attribute__ ((used, section ("__libc_atexit"))) = &_IO_cleanup;
/* http://sources.redhat.com/bugzilla/show_bug.cgi?id=3400 */

const void *__bring_in_IO_cleanup(void);
const void *__bring_in_IO_cleanup(void) {
  return __elf_set___libc_atexit_element__IO_cleanup__;
}

int udpc_dialog_main(int argc, char **argv);
int udpc_dialog_main(int argc, char **argv)
#else
const char *bb_applet_name="udpcdialog";
int main(int argc, char **argv)
#endif
{
  int i;

#ifndef NO_BB
  if(__bring_in_IO_cleanup() == 0)
    /* Do something with the result, so that compiler wouldn't simply
       optimize it away... */
    return 0;
#endif
  if(argc >= 2 && !strcmp(argv[1], "init")) {
    return !udpc_makeDevices();
  }

  systemf(1, "/predialog");
  systemf(1, "/%s.predialog", cmd[udpc_config.modeIdx]);
  udpc_makeDevices(); /* Call this again, just in case the predialog script
		       * created any new devices */

  while(1) {
    int c = getopt( argc, argv, "tS:");
    if (c == EOF) break;
    switch (c) {
    case 't':
      udpc_testMode = 1;
      break;
    case 'S':
      close(2);
      open(optarg, O_WRONLY|O_CREAT|O_APPEND, 0644);
      break;
    case '?':
#ifndef NO_BB
      bb_show_usage();
#endif
      break;
    }
  }

  /* Allow rebooting via ctrl-alt-del */
  set_parm("/proc/sys/kernel/ctrl-alt-del", 1);

  /* Set the memory buffers to a value large enough for udpcast */
  set_parm("/proc/sys/net/core/wmem_max", 1048576);
  set_parm("/proc/sys/net/core/wmem_default", 1048576);
  set_parm("/proc/sys/net/core/rmem_max", 1048576);
  set_parm("/proc/sys/net/core/rmem_default", 1048576);



  /* Switch off printing of kernel messages to console */
  klogctl(6,0,0);

  /* Zero out config */
  udpc_clearConfig(&udpc_config, desc);
  udpc_loadConfigEnv(&udpc_config, desc, 0);
  udpc_loadConfig("udpcfg.txt", &udpc_config, desc, 0);
  
  /* maybe we have a floppy? */
  for(i=0; i<sizeof(floppyModules)/sizeof(floppyModules[0]); i++)
    udpc_modprobe(floppyModules[i], "");
  udpc_haveFloppy=!udpc_mountFloppy(0, NULL);
  if(udpc_haveFloppy) {
    int fd;
    udpc_loadConfig("/floppy/udpcfg.txt", &udpc_config, desc, 0);

    /* If floppy flag is set, copy any items (*.o, *.o.gz, *.ko, *.ko.gz and *.tar) from host
     * floppy */
    udpc_loadModulesFromFloppy("/floppy/");

    fd = open("/floppy/ipmac.txt", O_RDONLY);
    if(fd >= 0) {
      int out = open("/tmp/ipmac.txt", O_WRONLY|O_CREAT, 0644);
      if(out >= 0) {
	bb_copyfd_eof(fd, out);
	close(fd);
	close(out);
      } else
	perror("write /tmp/ipmac.txt file");
    } else {
      perror("open ipmac.txt file");
    }
    udpc_umountFloppy();
  }

  /* ... or a CD? */
  udpc_haveCd = !udpc_mountCd();
  if(udpc_haveCd) {
    udpc_loadConfig("/cd/udpcfg.txt",  &udpc_config, desc, 0);
    udpc_umountCd();
  }

  init_dialog();
  mainDialog();
  end_dialog();

  {
      int r;
      const char *base = cmd[udpc_config.modeIdx];
      close(2);
      r=dup(1);

      systemf(1, "/pre");
      systemf(1, "/%s.pre", base);
      r=systemf(0, "%s%s --file %s -P %d -i %s %s %s",
		base, compr[udpc_config.modeIdx * 3 + udpc_config.comprIdx],
		udpc_config.disk,
		udpc_config.port ? udpc_config.port : 9000,
		iface,
		udpc_config.udpcParam,
		udpc_config.modeIdx ? udpc_config.udpsParam : udpc_config.udprParam);
      systemf(1, "/%s.post %d",base, r);
      systemf(1, "/post %d", r);
  }
  return 0;
}
