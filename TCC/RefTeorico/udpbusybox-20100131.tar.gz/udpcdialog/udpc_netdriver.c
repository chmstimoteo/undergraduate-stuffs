#ifndef _GNU_SOURCE
#define _GNU_SOURCE
#endif

#include "udpc_lang.h"
#include "udpc_dialog.h"
#include "udpc_dev.h"
#include "libbb.h"

/* ===============================================================
 * Setting of net module configuration
 * =============================================================== */
static int netPciClasses[] = { 0x200, 0x680 };
static int netUsbClasses[] = { 0x0003, 0x0013, 0x0380 };

static const char *netPrefixes[] = { "drivers/net/" };

/* Probe for PCMCIA cards */
static int udpc_probecards(void)
{
  return system("/bin/probecards");
}

static int none(const char *ifc) {
  return udpc_getMac(ifc, NULL) == -1;
}

static int net_isReady(void) {
  /* we have a mac address ==> ok */
  return !forAllNetInterfaces(none, 0);
}

static modules_t netModules = {
  .pciClasses = netPciClasses,
  .nPciClasses = sizeof(netPciClasses) / sizeof(netPciClasses[0]),
  .usbClasses = netUsbClasses,
  .nUsbClasses = sizeof(netUsbClasses) / sizeof(netUsbClasses[0]),
  .prefixes = netPrefixes,
  .nPrefixes = sizeof(netPrefixes) / sizeof(netPrefixes[0]),
  .title = "Network driver config",
  .initFn = udpc_probecards,
  .isReadyFn = net_isReady,
  .choiceListPtr = NULL,
  .paramPrompt = TXT_ENTER_PARAMS,
  .prompt = TXT_LOAD_NET,
  .height = 17
};


int udpc_configureNetDriver(int forceManual, int step)
{
  netModules.modName       = udpc_config.netModule;
  netModules.modParams     = udpc_config.netParam;
  netModules.modParamIsSet = &udpc_config.netParamIsSet;
  return udpc_configureDriver(&netModules, forceManual, step);
}
