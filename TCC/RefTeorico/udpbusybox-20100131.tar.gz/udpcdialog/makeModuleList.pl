#!/usr/bin/perl

use strict;
use English;

my @list;

# First make map of modules and their names
foreach my $path (@ARGV) {
  my $desc = `modinfo --description $path`;
  chomp $desc;
  if($desc =~ /^"(.*)"$/) {
    $desc=$1;
  }
  if($desc eq "<none>" || $desc eq "") {
    if($path =~ /.*\/(.*)\.o/){
      $desc=$1;
    }
  }
  if($path =~ /^\/lib\/modules\/[^\/]+\/(.*)/) {
    $path=$1;
  }
  if(length($desc) > 59) {
    $desc = substr($desc,0,59);
  }
  $desc =~ s/\s+/ /g;
  push(@list, "$path $desc\n");
}

@list = sort @list;

print scalar(@list)."\n";
foreach my $elt (@list) {
  print $elt;
}

print "\n";
