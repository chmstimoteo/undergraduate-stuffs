#!/bin/sh


while : ; do
    if [ $# -eq 0 ] ; then
	exit 0;
    fi
    mod=$1
    shift
    desc=`modinfo --description $mod`
    if [ "X$desc" = "X<none>" ] ; then
	desc="\"`basename $mod .o`\""
    fi
    echo -n "  { \"`basename $mod`\", $desc }"

    echo
done
