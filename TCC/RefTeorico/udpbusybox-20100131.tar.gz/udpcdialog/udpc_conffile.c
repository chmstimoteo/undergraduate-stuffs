#ifndef _GNU_SOURCE
#define _GNU_SOURCE
#endif
#include <sys/socket.h>
#include <stdio.h>
#include <stdlib.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <string.h>
#include "udpc_conffile.h"
#include "udpc_dialog.h"

static int setValue(void *dst, void *src, struct configDesc *desc,
		    int doOverwrite)
{
  void *value = (void *) ( ((char *)dst)+desc->offset);

  if(!doOverwrite && desc->flagOffset != -1) {
    int *flag = (int *) ( ((char *)dst)+desc->flagOffset);
    if(*flag)
      return 0;
  }

  switch(desc->type) {
  case TYPE_NONNULL_STRING:
    if(!doOverwrite && *((char*)value) != '\0')
      return 0;
    /* FALL THROUGH */
  case TYPE_STRING:
    nt_strncpy(value, src, desc->length);
    break;
  case TYPE_BOOLEAN:
    if(!doOverwrite && *((int*)value) != -1) {
      return 0; /* value already set */
    }
    if(!strcmp(src, "yes") || 
       !strcmp(src, "1") ||
       !strcmp(src, "true") ||
       !strcmp(src, "on") ||
       !strcmp(src, "")) {
      * ((int*)value) = 1;
    } else {
      * ((int*)value) = 0;
    }
    break;
  case TYPE_INTEGER:
    * ((int*)value) = strtol(src,0,0);
    break;
  case TYPE_IP:
    if(inet_aton(src, (struct in_addr*)value) == 0)
      return 0;
    break;
  default:
    fprintf(stderr, "Unknown data type %d\n", desc->type);
    return -1;
  }
  if(desc->flagOffset != -1) {
    int *flag = (int *) ( ((char *)dst)+desc->flagOffset);
    *flag = 1;
  }
  return 0;
}

static int printValue(void *data, FILE *f, struct configDesc *desc)
{
  void *value  = (void*) ( ((char *)data)+desc->offset);

  if(desc->flagOffset != -1) {
    int *flag = (int *) ( ((char *)data)+desc->flagOffset);
    if(!*flag) {
      return 0;
    }
  }

  switch(desc->type) {
  case TYPE_NONNULL_STRING:
    if( *(char *) value == '\0')
      return 0; /* not set */
    break;
  case TYPE_BOOLEAN:
    if( * ((int*)value) == -1) {
      return 0; /* not set */
    }
    break;
  }

  fprintf(f, "%s=",desc->name);
  switch(desc->type) {
  case TYPE_NONNULL_STRING:
  case TYPE_STRING:
    fprintf(f, "%s", (char *)value);
    break;
  case TYPE_BOOLEAN:
    fprintf(f, "%s", *((int*)value) ? "yes" : "no");
    break;
  case TYPE_INTEGER:
    fprintf(f, "%d", *((int*)value));
    break;
  case TYPE_IP:
    fprintf(f, "%s", inet_ntoa(*((struct in_addr *)value)));
    break;
  default:
    fprintf(stderr, "Unknown data type %d\n", desc->type);
    break;
  }
  fprintf(f, "\n");
  return 0;
}

#define BUFSIZE 2000

int udpc_loadConfig(const char *file, void *data, struct configDesc *desc,
		    int doOverwrite)
{
  char buffer[BUFSIZE];
  char *ptr;
  char *eptr;
  FILE *f = fopen(file, "r");
  if(f == NULL)
    /* Config file not found, return */
    return -1;
  while( (ptr=fgets(buffer, BUFSIZE-1, f))) {
    int totalLength = strlen(ptr);
    while(totalLength > 0 && 
	  (ptr[totalLength-1] == '\n' || ptr[totalLength-1] == '\r')) {
      ptr[totalLength-1]='\0';
      totalLength--;
    }

    /* Skip leading spaces */
    while(*ptr == ' ' || *ptr == '\t') {
      ptr++;
    }

    /* If this is a comment, skip it */
    if(ptr[0] == '#') {
      continue;
    }
    
    if( (eptr = strchr(ptr, '=')) ) {
      int i;
      unsigned int keyLength = eptr - ptr;
      for(i=0; desc[i].name; i++) {
	if(strlen(desc[i].name) == keyLength &&
	   strncmp(desc[i].name,ptr,keyLength) == 0) {
	  /* Found a match */
	  setValue(data, eptr+1, &desc[i], doOverwrite);
	}
      }
      
    }

  }
  fclose(f);
  return 0;
}

int udpc_loadConfigEnv(void *data, struct configDesc *desc,int doOverwrite)
{
  int i;
  for(i=0; desc[i].name; i++) {
    char *x = getenv(desc[i].name);
    if(x != NULL)
      setValue(data, x, &desc[i], doOverwrite);
  }  
  return 0;
}

int udpc_clearConfig(void *data, struct configDesc *desc)
{
  int i;
  for(i=0; desc[i].name; i++) {
    void *value  = (void*) ( ((char *)data)+desc[i].offset);
    if(desc[i].flagOffset != -1) {
      int *flag = (int *) ( ((char *)data)+desc[i].flagOffset);
      *flag = 0;
    }
    switch(desc[i].type) {
    case TYPE_INTEGER:
      * ((int *) value) = 0;
      break;
    case TYPE_NONNULL_STRING:
    case TYPE_STRING:
      * ((char *) value) = '\0';
      break;
    case TYPE_BOOLEAN:
      * ((int *)value) = -1;
      break;
    case TYPE_IP:
      inet_aton("10.0.0.0", (struct in_addr*)value);
      break;
    }
  }  
  return 0;
}

int udpc_saveConfig(const char *file, void *data, struct configDesc *desc)
{
  int i;
  FILE *f = fopen(file, "w");
  if(f == NULL) {
    return -1;
  }
  for(i=0; desc[i].name; i++) {
    printValue(data, f, &desc[i]);
  }
  fclose(f);
  return 0;
}
