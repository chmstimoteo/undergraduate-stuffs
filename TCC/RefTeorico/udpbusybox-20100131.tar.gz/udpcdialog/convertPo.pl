#!/usr/bin/perl

# Takes a input a bunch of .po files, and transforms them into lang.c file
# Such preprocessing is preferable to doing it at runtime, in order to
#
use strict;
use English;
use Text::Iconv;

my @defines;
my @lang=('en');
my %msgStr;
my %msgId;
my $enDict;

sub storeData {
  my ($define, $enDict, $dict, $msgId, $msgStr, $file, $lang) = @_;
  return if(!defined $define);
  if(defined $msgId) {
    if(!defined $enDict->{$define}) {
      $enDict->{$define} = $msgId;
      push(@defines, $define);
    } elsif($msgId ne $enDict->{$define}) {
      print STDERR 
	"WARNING: English message of $define differs in $file: $msgId vs $enDict->{$define}\n";
	  }
  }
  if(defined $msgStr) {
    if(defined $dict->{$define}) {
      die "Duplicate entry $define in $lang\n";
    }
    $dict->{$define} = $msgStr;
  }
}

my $converter = Text::Iconv->new("iso-8859-1", "cp437");

sub toCp437 {
  my ($in) = @_;
  my $res= $converter->convert($in);
  if($res ne "") {
    return $res;
  } else {
    return $in . "/* !! */";
  }
}

sub processFile {
  my ($file) = @_;
  my $define = undef;
  my $lang;
  my $msgId;
  my $msgStr;
  my $state;


  if($file =~ /(.*\/)?(.*)\.po$/) {
    $lang = $2;
  } else {
    die "Bad file $file\n";
  }

  push(@lang, $lang);
  my $dict = {};
  open(FILE, "<$file") || die "Could not read $file (ERRNO)\n";
  while(<FILE>) {
    chomp;
    if(/^\#\. (.*)/) {
      my $newDef = $1;
      storeData($define, $enDict, $dict, $msgId, $msgStr, $file, $lang);
      $define = $newDef;
      undef $msgId;
      undef $msgStr;
      $state = "";
    } elsif(/^msgid (.*)/) {
      $msgId = $1;
      $state = "MSGID";
    } elsif(/^msgstr (.*)/) {
      $msgStr = $1;
      $state = "MSGSTR";
    } elsif(/\"/) {
      if($state eq "MSGID") {
	$msgId .= "\n    ".$_;
      } elsif($state eq "MSGSTR") {
	$msgStr .= "\n   ".$_;
      }
    }
  }
  close(FILE);
  storeData($define, $enDict, $dict, $msgId, $msgStr, $file, $lang);
  $msgStr{$lang} = $dict;
}

$enDict={};
$msgStr{'en'}= $enDict;
foreach my $file (glob "*.po") {
  processFile($file);
}

# Write the .h file
open(H_FILE, ">udpc_lang.h") || die "Could not open .h file ($ERRNO)\n";
print H_FILE "#ifndef LANG_H\n";
print H_FILE "#define LANG_H\n";
print H_FILE "\n";
for(my $i=0; $i < @defines; $i++) {
  print H_FILE "#define $defines[$i] $i\n";
}

print H_FILE "\n";


for(my $i=0; $i < @lang; $i++) {
  print H_FILE "#define ".uc($lang[$i])." $i\n";
}
print H_FILE "\n";
print H_FILE "extern const char *udpc_msg[".scalar(@lang)."][".scalar(@defines)."];\n";
print H_FILE "extern unsigned int udpc_language;\n";
print H_FILE "#define MSG(x) (udpc_msg[udpc_language][(x)])\n";
print H_FILE "\n";

print H_FILE "#endif\n";
close(H_FILE);

open(C_FILE, ">udpc_lang.c") || die "Could not open .c file ($ERRNO)\n";
print C_FILE "#include \"udpc_lang.h\"\n";

print C_FILE "\n";
print C_FILE "const char *udpc_msg[".scalar(@lang)."][".scalar(@defines)."]={\n";

my $firstLang=1;
foreach my $lang (@lang) {
  if(!$firstLang) {
    print C_FILE ",\n";
  }
  $firstLang=0;
  print C_FILE "  {\n";
  my $firstDefine=1;
  foreach my $msg (@defines) {
    if(!$firstDefine) {
      print C_FILE ",\n";
    }
    $firstDefine=0;
    if($msgStr{$lang}->{$msg} ne "") {
      print C_FILE "    ".toCp437($msgStr{$lang}->{$msg});
    } else {
      print C_FILE "    ".$msgStr{'en'}->{$msg}." /* ! */";
    }
  }
  print C_FILE "  }";
}
print C_FILE "\n};\n";
close(C_FILE);
