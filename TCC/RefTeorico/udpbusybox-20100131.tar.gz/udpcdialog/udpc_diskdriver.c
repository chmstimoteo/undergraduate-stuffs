#ifndef _GNU_SOURCE
#define _GNU_SOURCE
#endif
#include "udpc_lang.h"
#include "dialogExt.h"
#include "udpc_dialog.h"
#include "udpc_dev.h"
#include "libbb.h"

/* ===============================================================
 * Setting of disk module configuration
 * =============================================================== */
static int diskPciClasses[] = { 0x100, 0x101, 0x104, 0x180 };
static int diskUsbClasses[] = { 0x000f };

static const char *diskPrefixes[] = { "drivers/scsi/", "drivers/ata/", "drivers/usb/storage/" };

static modules_t diskModules = {
  .pciClasses = diskPciClasses,
  .nPciClasses = sizeof(diskPciClasses) / sizeof(diskPciClasses[0]),
  .usbClasses = diskUsbClasses,
  .nUsbClasses = sizeof(diskUsbClasses) / sizeof(diskUsbClasses[0]),
  .prefixes = diskPrefixes,
  .nPrefixes = sizeof(diskPrefixes) / sizeof(diskPrefixes[0]),
  .title = "Disk driver config",
  .initFn = NULL,
  .isReadyFn = NULL,
  .choiceListPtr = NULL,
  .paramPrompt = TXT_ENTER_PARAMS,
  .prompt = TXT_LOAD_DISK_MODULE,
  .height = 15
};

static int setPromptDiskmodule(int forceManual)
{
  int r;
  if(udpc_config.enableDiskmodule != -1 && !forceManual)
    return 0;
  r = dialog_yesno(diskModules.title, MSG(TXT_LOAD_DISK_YESNO), 6, 50, 
		   (udpc_config.enableDiskmodule == 0));
  dialog_clear();
  if(r < 0)
    return -1;
  udpc_config.enableDiskmodule = 1-r;
  return r;
}

int udpc_configureDiskDriver(int forceManual, int step)
{
  int r;

  while(1) {
    if(setPromptDiskmodule(forceManual) < 0)
      return -1;
    if(udpc_config.enableDiskmodule==0)
      return 0;

    diskModules.modName       = udpc_config.diskModule;
    diskModules.modParams     = udpc_config.diskParam;
    diskModules.modParamIsSet = &udpc_config.diskParamIsSet; 
    r = udpc_configureDriver(&diskModules, forceManual, step);
    if(r == -1)
      continue; /* Loop back to the YES/NO dialog */

    if(r == 0) {
      int k=0;
      udpc_clearKlog();
      if(udpc_modprobe("sd_mod", "")) {
	if(!udpc_displayKlog(1))
	  /* If no kernel error, display applicative error */
	  udpc_display_error();
      }
      /* Call this again to see any new devices */
      while(k < 100 && !udpc_makeDevices()) {
	usleep(30000);
	k++;
      }
    }
    return r;
  }
}
