#ifndef _GNU_SOURCE
#define _GNU_SOURCE
#endif
#include <string.h>
#include <unistd.h>
#include <stdio.h>
#include <errno.h>
#include <fcntl.h>
#include <ftw.h>
#include <sys/utsname.h>
#include "udpc_lang.h"
#include "dialogExt.h"
#include "udpc_dev.h"
#include "udpc_dialog.h"
#include "libbb.h"

/* PCI Modules */
struct module_t {
  char *path;
  int dirlen;
  const char *shortname;
  char *comment;
};

struct devmap {
  unsigned int module;
  unsigned int major;
  unsigned int minor;
  unsigned int submajor;
  unsigned int subminor;
  unsigned int isUsb;
  unsigned int usbFlags;
};

static struct pci {
  unsigned short major;
  unsigned short minor;
  unsigned short s02;
  unsigned short s03;
  unsigned short rev;
  unsigned short dclass;
  unsigned short s06;
  unsigned short s07;

  unsigned int resource1;
  unsigned int resource2;
  unsigned int resource3;
  unsigned int resource4;

  unsigned short s20;
  unsigned short s21;
  unsigned short s22;
  unsigned short s23;
  unsigned short s24;
  unsigned short s25;
  unsigned short submajor;
  unsigned short subminor;

  unsigned short s30;
  unsigned short s31;
  unsigned short s32;
  unsigned short s33;
  unsigned short s34;
  unsigned short s35;
  unsigned char  irq;
  unsigned char  ch3d;
  unsigned short s37;
} pci;


static char *getBasename(const char *in, int suffixStrip) {
  const char *ptr;
  int l;

  ptr = strrchr(in, '/');
  if(ptr == NULL)
    ptr = in; 
  else
    ptr++;
  l = strlen(ptr);
  if(l >= suffixStrip)
    l -= suffixStrip;
  return strndup(ptr, l);
}

#define LABELSIZE 13
#define DESCSIZE 58

struct moduleChoiceListEntry {
  int idx; /* Index in module struct */
  char label[LABELSIZE+1];
  char desc[DESCSIZE+1];
};

/* List of all available modules, not just those
   proposed for choice right now: */
static struct module_t *available=NULL; /* List */
static unsigned int nAvailable; /* number */

static char *modulesKernelDirectory=NULL;
static const char *modulesPrefix="/lib/modules/";

static char *getModulesKernelDirectory(void)
{
  struct utsname uts;

  if(modulesKernelDirectory == NULL) {
    if(uname(&uts) < 0) {
      udpcd_fatal("Couldn't get kernel version: %s", strerror(errno));
    }
    modulesKernelDirectory=
      xmalloc(strlen(modulesPrefix)+strlen(uts.release)+2);
    strcpy(modulesKernelDirectory, modulesPrefix);
    strcat(modulesKernelDirectory, uts.release);
    strcat(modulesKernelDirectory, "/");
  }
  return modulesKernelDirectory;
}

static void addChoice(modules_t *mods,
		      int idx, const char *filename, const char *desc,
		      int checkDuplicates)
{
  const char *ptr;
  struct moduleChoiceListEntry *entry;
  const char **entryPtr;
  int l;
  unsigned int i;

  if(mods->choiceList==NULL) {
    mods->choiceListTotalSize=nAvailable+2; /* Initial size */
    mods->choiceList = 
      xmalloc(mods->choiceListTotalSize*sizeof(struct moduleChoiceListEntry));
    mods->choiceListPtr = 
      xmalloc(2*mods->choiceListTotalSize*sizeof(char*));
  }

  /* Check for duplicates... */
  if(checkDuplicates) {
    for(i=0; i<mods->choiceListSize; i++) {
      if(mods->choiceList[i].idx == idx)
	return;
    }
  }

  entry = &mods->choiceList[mods->choiceListSize];
  entryPtr = &mods->choiceListPtr[2*mods->choiceListSize];

  entry->idx = idx;

  ptr=strrchr(filename,'/');
  if(ptr==NULL)
    ptr=filename;
  else
    ptr++;
  l=strlen(ptr)-2;
  if(l > LABELSIZE)
    l = LABELSIZE;
  if(l<0)
    l=0;
  strncpy(entry->label, ptr, l);
  entry->label[l]='\0';
  entryPtr[0] = entry->label;

  ptr=desc;
  l=strlen(ptr);
  if(l > DESCSIZE)
    l = DESCSIZE;
  if(l<0)
    l=0;
  strncpy(entry->desc, ptr, l);
  entry->desc[l]='\0';
  entryPtr[1] = entry->desc;
  mods->choiceListSize++;
}

/**
 * Load /lib/modules/modules.info file. This data may be shared by all
 * module types
 */
static unsigned int loadModuleInfo(void)
{
  char buffer[200];
  char *ptr;
  FILE *f;
  unsigned int i=0;
  unsigned int n;
  struct module_t *modules;
  const char *filename;
  const char *kernelDir;
  int kernelDirLen;

  if(available)
    return 0; /* already loaded */

  kernelDir = getModulesKernelDirectory();
  kernelDirLen = strlen(kernelDir);

  filename="/lib/modules/modules.info";
  f = fopen(filename, "r");
  if(f == NULL) {
    udpc_fileNotFound(filename);
    return -1;
  }
  ptr=fgets(buffer, sizeof(buffer)-1, f);
  if(ptr == NULL) {
    udpcd_fatal("Module info file empty");
    return -1;
  }
  n = strtoul(buffer, 0, 0);
  modules = xmalloc(n*sizeof(struct module_t));
  while( (ptr=fgets(buffer, sizeof(buffer)-1, f)) ) {
    struct module_t *entry;
    char *ptr2;
    int len;
    chomp(buffer);
    
    if(i>=n) {
      /* too many entries */
      break;
    }
    entry= &modules[i];
    ptr2=strchr(ptr, ' ');

    entry->path = xmalloc(kernelDirLen+ptr2-ptr+1);
    strcpy(entry->path, kernelDir);
    strncat(entry->path, ptr, ptr2-ptr);

    entry->comment = strdup(ptr2+1);
    ptr2 = strrchr(entry->path, '/');
    if(ptr2)
      ptr2++;
    else
      ptr2=entry->path;
    entry->dirlen = ptr2 - entry->path;
    len = strlen(ptr2);
    if(len > 2 && !strcmp(ptr2+len-2, ".o"))
      entry->shortname = strndup(ptr2, len - 2);
    else if(len > 3 && !strcmp(ptr2+len-3, ".ko"))
      entry->shortname = strndup(ptr2, len - 3);
    else
      entry->shortname = "";
    i++;
  }
  fclose(f);
  available= modules;
  nAvailable = i;
  return 0;
}

static unsigned int getNum(char **ptr)
{
  /* skip spaces */
  while(**ptr==' ')
    (*ptr)++;
  return strtoul(*ptr, ptr, 0);
}

static int moduleMatches(char *name, int pos)
{
  if(pos == -1 || (unsigned int) pos >= nAvailable)
    return 0;
  return !strcmp(name, available[pos].shortname);
}

static int findModuleByName(char *name, int guess)
{
  unsigned int i;
  if(moduleMatches(name, guess))
    return guess;
  for(i=0; i<nAvailable; i++) {
    if(moduleMatches(name, i))
       return i;
  }
  return -1;
}

static struct devmap *udpc_devmap[2]={ NULL, NULL};
static unsigned int udpc_nDevmap[2];

static int loadDevmap(int isUsb)
{
  char buffer[200];
  char *ptr;
  FILE *f;
  int size;
  int i=0;
  int lastModule = -1;
  struct devmap *map;

  if(udpc_devmap[isUsb])
    return 0; /* already loaded */

  snprintf(buffer, sizeof(buffer)-1, "%smodules.%smap",
	   getModulesKernelDirectory(), isUsb ? "usb" : "pci");
  size = udpc_countLines(buffer);
  if(size < 0)
    return -1; /* File not found */
  map = xmalloc(size * sizeof(struct devmap));
  f = fopen(buffer, "r");
  if(f == NULL) {
    udpc_fileNotFound(buffer);
    free(map);
    return -1;
  }
  while( (ptr = fgets(buffer, sizeof(buffer)-1, f)) ) {
    struct devmap *entry;
    char *ptr2;
    if(*ptr == '#')
      continue;
    
    ptr2 = strchr(ptr, ' ');
    if(!ptr2) {
      continue;
    }
    *ptr2='\0';
    ptr2++;

    lastModule = findModuleByName(ptr, lastModule);
    if(lastModule < 0) {
      continue;
    }

    if(i == size) {
      udpc_alert("Devmap has more lines than expected, ignoring the end\n");
      break;
    }

    entry = &map[i];
    entry->module = lastModule;
    /* Skip over match_flags */
    if(isUsb)
      entry->usbFlags=getNum(&ptr2);
    entry->isUsb=isUsb;
    entry->major=getNum(&ptr2);
    entry->minor=getNum(&ptr2);
    if(isUsb) {
      entry->submajor=0;
      entry->subminor=0;
    } else {
      entry->submajor=getNum(&ptr2);
      entry->subminor=getNum(&ptr2);
    }
    i++;
  }
  fclose(f);
  udpc_devmap[isUsb]=map;
  udpc_nDevmap[isUsb]=i;
  return 0;
}

/* We are not multithreaded here, so we can afford this... */
static modules_t *ftwMods;

static int moduleTail(int isUsb,
		      unsigned short major,
		      unsigned short minor,
		      unsigned short submajor,
		      unsigned short subminor) {
  int i,j;
  for(j=0; j<2 ; j++) {
    for(i=0; i<udpc_nDevmap[isUsb]; i++) {
      struct stat buf;
      struct devmap *map = &udpc_devmap[isUsb][i];
      struct module_t *mod;
      if(major != map->major)
	continue;
      if(minor != map->minor)
	continue;
      if(!isUsb &&
	 map->submajor != 0xffffffff && 
	 map->submajor != submajor)
	continue;
      if(!isUsb &&
	 map->subminor != 0xffffffff && 
	 map->subminor != subminor)
	continue;

      if(isUsb) {
	int k=0;
	for(k=0; k<ftwMods->nUsbClasses; k++) {
	  if(map->usbFlags == ftwMods->usbClasses[k])
	    break; /* Class found */
	}
	if(k == ftwMods->nUsbClasses)
	  /* Not a device of correct type */
	  continue;
      }
    
      /* Ok, module seems to match. Now check presence of file */
      mod = &available[map->module];

      if(stat(mod->path, &buf) < 0) {
	/* no such file, wait for second pass */
	if(j==0)
	  continue;
      } else if(j!=0)
	continue;
      
#if 0
      udpc_info("Found a device %04x:%04x (rev %x): %s", 
		pci.major, pci.minor, pci.rev, mod->comment);
#endif

      addChoice(ftwMods, map->module, mod->path, mod->comment, 1);
    }
  }
  return 0;
}


static int pciModuleHandler(const char *path, const struct stat *sb, int flag)
{
  int f,n;
  unsigned int i;
  (void)sb;
  if(flag != FTW_F)
    return 0;
  f = open(path, O_RDONLY);
  if(f < 0) {
    /* Move on to the next */
    fprintf(stderr, "Could not open %s (%s)\n", path, strerror(errno));
    return 0;
  }
  n = read(f, &pci, sizeof(pci));
  close(f);
  if(n < (int) sizeof(pci)) {
    fprintf(stderr, "Short read on %s (%s); %d\n", path, strerror(errno), n);
    return 0;
  }
  for(i=0; i<ftwMods->nPciClasses; i++) {
    if(pci.dclass == ftwMods->pciClasses[i])
      break; /* Class found */
  }

  if(i == ftwMods->nPciClasses)
    /* Not a device of correct type */
    return 0;
  return moduleTail(0, pci.major, pci.minor, pci.submajor, pci.subminor);
}

static int usbModuleHandler(const char *path, const struct stat *sb, int flag)
{
  char tmpPath[MAXPATHLEN+12];
  char buf[80];
  int fd;
  short major;
  short minor;
  int n;

  (void) sb;
  (void) flag;
  strcpy(tmpPath, path);
  strcat(tmpPath, "/idVendor");
  fd = open(tmpPath, O_RDONLY);
  if(fd < 0)
    return 0;
  n=read(fd, buf,80);
  close(fd);
  if(n < 4)
    return 0;

  major = strtoul(buf, NULL, 16);

  strcpy(tmpPath, path);
  strcat(tmpPath, "/idProduct");
  fd = open(tmpPath, O_RDONLY);
  if(fd < 0)
    return 0;
  n=read(fd, buf,80);
  close(fd);
  if(n < 4)
    return 0;

  minor = strtoul(buf, NULL, 16);

  return moduleTail(1, major, minor, 0, 0);
}

/**
 * Find hardware matching the installed classes
 */
static int autodetectHardware(modules_t *mods)
{
  ftwMods = mods;
  mods->choiceListSize=0;
  ftw("/proc/bus/pci", pciModuleHandler, 10);
  ftw("/sys/devices", usbModuleHandler, 10);
  if(mods->choiceListSize) {
    addChoice(mods, -1,"OTHER.o", MSG(TXT_MORE_MODULES), 1);
    return 0;
  } else {
    return -1;
  }
}

static void completeList(modules_t *mods)
{
  unsigned int i=0;
  unsigned int j=0;
  mods->choiceListSize=0;
  for(i=0; i < nAvailable; i++) {
    struct module_t *mod = &available[i];
    char *ptr=mod->path;

    /* Skip 5 slashes */
    for(j=0; j<5; j++)
      ptr += strcspn(ptr, "/")+1;

    for(j=0; j<mods->nPrefixes; j++) {
      int l = strlen(mods->prefixes[j]);
      if(!strncmp(ptr, mods->prefixes[j],l)) {
	addChoice(mods, i, mod->path, mod->comment, 0);
      	break;
      }
    }
  }
}


/* Choice of module */
static int _choseModule(modules_t *mods, int forceManual, const char *deflt)
{
  unsigned int r=0;
  if(deflt) {
    for(r=0; r <mods->choiceListSize; r++) {
      int idx = mods->choiceList[r].idx;
      if(idx == -1)
	continue;
      if(!strcmp(available[idx].shortname, deflt)) {
	if(!forceManual)
	  return r;
	else 
	  break;
      }
    }
    if(r==mods->choiceListSize)
      r=0;
  }

  r = dialog_menu(mods->title, MSG(mods->prompt), 23, 79, mods->height, 
		  mods->choiceListSize, mods->choiceListPtr, r);
  dialog_clear();
  if(r < 0 || (unsigned int) r >= mods->choiceListSize) {
    return -2;
  }
  return r;
}

/* Choice of a module */
static struct module_t *choseModule(modules_t *mods, int forceManual)
{
  struct module_t *mod;
  int r;
  int choice;
  int autodetected=1;
  if(!mods->modName[0])
    forceManual=1;

  mods->choiceListSize=0;
  if(forceManual || strcmp(mods->modName, "AUTO") == 0) {
    autodetectHardware(mods);
    if(!forceManual && mods->choiceListSize >= 2)
      return &available[mods->choiceList[0].idx];
  }
  while(1) {
    if(mods->choiceListSize==0) {
      autodetected=0;
      completeList(mods);
    }
    r=_choseModule(mods, forceManual, mods->modName);
    if(r==-2)
      return NULL;
    choice = mods->choiceList[r].idx;
    if(choice == -1) {
      mods->choiceListSize=0;
      continue;
    }
    break;
  }
  mod = &available[choice];
  if(r==0 && autodetected)
    nt_strncpy(mods->modName, "AUTO", MODSIZE);  
  else
    nt_strncpy(mods->modName, mod->shortname, MODSIZE);
  return mod;
}

/* Input of module parameters */
static int enterModuleParams(modules_t *mods, int forceManual, 
			     struct module_t *mod)
{
  int r;
  int size=40;
  char *txt;

  if(*(mods->modParamIsSet) && !forceManual)
    return 0;

  txt = udpc_format(&size, MSG(mods->paramPrompt), mod->shortname);
  r=dialog_inputbox(mods->title, txt,	
		    10, size, mods->modParams);
  dialog_clear();
  if(r)
    return r;
  nt_strncpy(mods->modParams, dialog_input_result, MODPARAMSIZE);
  *(mods->modParamIsSet)=1;
  return 0;
}

int udpc_configureDriver(modules_t *mods, int forceManual, int step)
{
  struct stat buf;
  struct module_t *mod = NULL;
  int stepBase = step & 0xff00;
  if(udpc_config.automatic != 1)
    forceManual=1;

  loadModuleInfo();
  loadDevmap(0);
  loadDevmap(1);

  if(mods->initFn)
    mods->initFn();

  while(1) {
    if(mods->isReadyFn && mods->isReadyFn()) {
      /* we have already the needed hardware,
       * do not bother loading another driver! */
      if((step & 0xff) == 0xff)
	return -1; /* We are going back, continue going back! */
      else
	return 0;
    }

    switch(step & 0xff) {
    case 1:
      mod=choseModule(mods, forceManual);
      if(mod == NULL) {
	return -1;
      }
      step = stepBase + 2;
      break;

    case 2:
      if(enterModuleParams(mods, forceManual, mod)) {
	step = stepBase + 1;
	forceManual = 1;
	continue;
      }
      step = stepBase + 3;
      break;

    case 3:
      if(udpc_haveFloppy && stat(mod->path, &buf) < 0) {
	int r;
	udpc_fileNotFound(mod->path);
	/* Module does not exist, prompt for disk */
	r=udpc_mountFloppy(1, MSG(TXT_ENTER_MODDISK));
	if(r) {
	  forceManual=1;
	  step = STEP_NETDRV + 2;
	  continue;
	}
	udpc_loadModulesFromFloppy("/floppy");
	udpc_umountFloppy();
	if(mods->initFn)
	  mods->initFn();
	continue;
      }

      udpc_clearKlog();
      if(udpc_modprobe(mod->shortname, mods->modParams)) {
	if(!udpc_displayKlog(1))
	  /* If no kernel error, display applicative error */
	  udpc_display_error();
	step = STEP_NETDRV+1;
	forceManual = 1;
	continue;
      }

      if(forceManual)
	udpc_displayKlog(0);

      /* Do the modprobe here, and only return 0 if ok */
      return 0;

    case 0xff:
      step = stepBase + 1;
      continue;
    }
  }
}

enum fileCopyMode {
  OFILE,
  OGZFILE,
  TARGZFILE };

static const char *gunzipCmd[] = { "zcat", NULL };
static const char *tarXzvfCmd[] = { "tar", "xzvf", "-", NULL };

static int loadFromFloppyHandler(const char *path, const struct stat *sb, 
				 int flag)
{
  int len;
  int suffixLen=0;
  enum fileCopyMode mode;
  struct module_t *mod=NULL;
  int fd1;
  int fd2;

  if(flag != FTW_F)
    return 0; /* we only handle files */

  len = strlen(path);
  
  if(len > 2 && !strcmp(path+len-2, ".o")) {
    mode = OFILE;
    suffixLen = 2;
  } else if(len > 2 && !strcmp(path+len-3, ".ko")) {
    mode = OFILE;
    suffixLen = 3;
  } else if(len > 5 && !strcmp(path+len-5, ".o.gz")) {
    mode = OGZFILE;
    suffixLen = 5;
  } else if(len > 6 && !strcmp(path+len-6, ".ko.gz")) {
    mode = OGZFILE;
    suffixLen = 6;
  } else if(len > 7 && !strcmp(path+len-7, ".tar.gz")) {
    mode = TARGZFILE;
  } else {
    /* file not recognized... */
    fprintf(stderr, "Ignoring file \"%s\"\n", path);
    return 0;
  }

  fd1 = open(path, O_RDONLY);
  if(fd1 < 0) {
    fprintf(stderr, "Could not open \"%s\" (%s)\n", path, strerror(errno));
    return 0;
  }

  if(mode != TARGZFILE) {
    int idx;
    char *tmp = getBasename(path, suffixLen);

    /* TODO: go over all lists */

    loadModuleInfo();
    idx = findModuleByName(tmp, -1);
    if(idx == -1) {
      /* module unknown... */
      fprintf(stderr, "Module %s not known\n", tmp);
      free(tmp);
      close(fd1);
      return 0;
    }
    free(tmp);

    mod = &available[idx];

    tmp = strrchr(mod->path, '/');
    if(tmp) {
      tmp = strndup(mod->path, tmp-mod->path);
    } else {
      fprintf(stderr, "Missing directory for \"%s\"\n", mod->path);
      close(fd1);
      return 0;
    }

    /* make the directory */
    bb_make_directory(tmp, 0755, FILEUTILS_RECUR);
    
    /* in case file already exists, unlink it first... */
    unlink(mod->path);

    fd2=open(mod->path, O_WRONLY|O_CREAT|O_TRUNC, sb->st_mode & 07777);
    if(fd2 < 0) {
      fprintf(stderr, "Could not write \"%s\" (%s)\n", path, strerror(errno));
      close(fd1);
      return 0;
    }
  } else {
    fd2=2; /* stdout goes to error output */
  }

  switch(mode) {
  case OFILE:
    /* a simple copy */
    fprintf(stderr, "Copying %s to %s\n", path, mod->path);
    bb_copyfd_eof(fd1, fd2);
    break;
  case OGZFILE:
    fprintf(stderr, "Uncompressing %s to %s\n", path, mod->path);
    udpc_spawn(fd1, fd2, gunzipCmd);
    break;
  case TARGZFILE:
    fprintf(stderr, "Loading tar file \"%s\"\n", path);
    udpc_spawn(fd1, fd2, tarXzvfCmd);
    fprintf(stderr, "Loaded tar file \"%s\"\n\n", path);
    break;
  }
  close(fd1);
  if(fd2 != 2)
    close(fd2);
  return 0;
}

/* Copies over drivers from the host floppy (or CD) to the file system
 */
int udpc_loadModulesFromFloppy(const char *root)
{
  return ftw(root, loadFromFloppyHandler, 10);
}
