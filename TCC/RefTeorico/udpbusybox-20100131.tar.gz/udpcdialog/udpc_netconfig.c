#ifndef _GNU_SOURCE
#define _GNU_SOURCE
#endif
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <stdarg.h>
#include <errno.h>
#include <dirent.h>
#include <sys/ioctl.h>
#include <net/if.h>
#include <linux/types.h>
#include <linux/sockios.h>

#ifndef u8
#define u8 __u8
#endif

#ifndef u16
#define u16 __u16
#endif

#ifndef u32
#define u32 __u32
#endif

#ifndef u64
#define u64 __u64
#endif

#include <linux/ethtool.h>

#undef u64
#undef u32
#undef u16
#undef u8

#include <dirent.h>

#include "dialog.h"
#include "udpc_lang.h"
#include "udpc_dialog.h"
#include "udpc_conffile.h"

/* ===============================================================
 * Setting of IP configuration
 * =============================================================== */
static const char *title="IP config";

/**
 * Read DHCP config set by PXE loader
 */
static void udpc_loadConfigDhcp(void)
{
  struct in_addr netmask;
  struct in_addr ip;
  char *ipString;
  char ipField[16];
  char *ptr;

  /* Special case for DHCP client-supplied IP address */
  ipString = getenv("ip");
  if(ipString == NULL)
    return;

  ptr = strchr(ipString, ':');
  if(ptr == NULL || ptr-ipString > 15)
    return;

  strncpy(ipField, ipString, ptr-ipString);
  ipField[ptr-ipString]='\0';
  if(inet_aton(ipField, &ip) == 0)
    return;

  /* Skip over boot server IP */
  ptr = strchr(ptr+1, ':');
  if(ptr == NULL)
    return;

  /* Skip over router IP */
  ptr = strchr(ptr+1, ':');
  if(ptr == NULL)
    return;
  if(inet_aton(ptr+1, &netmask) == 0)
    return;
  udpc_config.ip = ip;
  udpc_config.ipIsSet=1;
  udpc_config.netmask = netmask;
  udpc_config.netmaskIsSet=1;
  udpc_config.doDhcp=0;
}

static int setDoDhcp(int forceManual)
{
  int r;
  if(udpc_config.doDhcp != -1 && !forceManual)
    return 0;
  r = dialog_yesno(title, MSG(TXT_ASK_BOOTP), 5, 50,
		   !(udpc_config.doDhcp != 0));
  dialog_clear();
  if(r < 0)
    return -1;
  udpc_config.doDhcp = 1-r;
  return r;
}

static int enterIp(int needInput, const char *myTitle, const char *message,
		   struct in_addr *ip, int *isSet, int checkNetmask)
{
  char buffer[16];
  if(!*isSet)
    needInput=1;
  if(!needInput)
    return 0;
  strcpy(buffer,inet_ntoa(*ip));
  while(1) {
    int r;
    r=dialog_inputbox(myTitle, message, 10, 40, buffer);
    if(r) {
      dialog_clear();
      return -1;
    }

    if(!inet_aton(dialog_input_result, ip)) {
      udpc_alert(MSG(TXT_INVALID_IP), dialog_input_result);
      dialog_clear();
      strncpy(buffer, dialog_input_result, 15);
      buffer[15]='\0';
      continue;
    }
    
    if(checkNetmask) {
      unsigned int v = ntohl(ip->s_addr);
      if( (v | (v-1)) != 0xffffffff) {
	udpc_alert(MSG(TXT_INVALID_NETMASK), dialog_input_result);
	dialog_clear();
	strncpy(buffer, dialog_input_result, 15);
	buffer[15]='\0';
	continue;
      }
    }

    *isSet=1;
    dialog_clear();
    return 0;
  }
}

static long long parseMac(char **macStrP)
{
  unsigned int byte=0;
  unsigned long long mac=0;
  char *macStr = *macStrP;

  while(1) {
    if(*macStr==':' || *macStr=='-') {
      mac = (mac << 8) | byte;
      byte = 0;
    } else if(*macStr >= '0' && *macStr <= '9') {
      byte = (byte << 4) | (*macStr - '0');
    } else if(tolower(*macStr) >= 'a' && tolower(*macStr) <= 'f') {
      byte = (byte << 4) | (tolower(*macStr) - 'a' + 10);
    } else {
      mac = (mac << 8) | byte;
      break;
    }
    macStr++;
  }
  *macStrP = macStr;
  return mac;
}

/**
 * Reads IpMac file fileName, and checks for presence of mac address hw
 * if found, return 1, else return 0
 */
static int readIpMacFile(const char *fileName, long long hw) {
  FILE *f = fopen(fileName, "r");
  char *ptr;
  char line[80];
  int r=0;
  if(f == NULL) {
    /* File does not exist */
    return 0;
  }

  while( (ptr=fgets(line, sizeof(line)-1, f)) ) {
    long long entry;
    ptr += strspn(ptr, " \t");
    if(*ptr == '#' || *ptr == '\n' || *ptr == '\r' || *ptr == '\0')
      continue;
    entry = parseMac(&ptr);
    if(entry == hw) {
      ptr += strspn(ptr, " \t");
      if(inet_aton(ptr, &udpc_config.ip)) {
	udpc_config.ipIsSet=1;
	udpc_config.doDhcp=0; /* Disable DHCP */
	r=1;
      }
      break;
    }
  }
  fclose(f);
  return r;
}

long long udpc_getMac(const char *ifname, char *ret)
{
  struct ifreq ifc;
  long long mac = 0;
  int i;

  int sockfd = socket(AF_INET, SOCK_DGRAM, 0);
  if(sockfd < 0)
    return -1;
  strcpy(ifc.ifr_name, ifname);
  if(ioctl(sockfd,  SIOCGIFHWADDR, &ifc) < 0) {
    close(sockfd);
    return -1;
  }
  close(sockfd);
  fprintf(stderr, "MAC Address of %s: ", ifname);
  for(i=0; i<6; i++) {
    int b = ifc.ifr_hwaddr.sa_data[i] & 0xff;
    mac = (mac << 8) + b;
    fprintf(stderr, "%s%02x", i ? ":" : "", b);
    if(ret != NULL)
      sprintf(ret+i*3, "%02x%s", b, i < 5 ? "-" : "");
  }
  fprintf(stderr, "\n");
  return mac;
}

static int ipMacRead=0;

/**
 * Reads IpMac file fileName, and checks for presence of mac address hw
 * if found, return 0, else return non null value
 */
static int readIpMacFilesForIf(const char *ifc)
{
  long long hw;
  int r;

  hw = udpc_getMac(ifc, NULL);
  if(hw < 0)
    return -1;

  r=readIpMacFile("/tmp/ipmac.txt", hw);
  if(!r)
    r=readIpMacFile("/ipmac.txt", hw);
  return !r;
}

static void readIpMacFiles(void)
{
  if(ipMacRead)
    return;
  forAllNetInterfaces(readIpMacFilesForIf, 1);
  ipMacRead=1;
}

static int configureIp(int forceManual)
{
  if(!udpc_config.ipIsSet)
    udpc_config.ip.s_addr = htonl(0x0a000000);
  return enterIp(forceManual, title, MSG(TXT_INPUT_IPADDR),
		 &udpc_config.ip, &udpc_config.ipIsSet, 0);
}

static int configureNetmask(int forceManual)
{
  if(!udpc_config.netmaskIsSet)
    udpc_config.netmask.s_addr = htonl(0xffff0000);
  return enterIp(forceManual, title, MSG(TXT_INPUT_NETMASK),
		 &udpc_config.netmask, &udpc_config.netmaskIsSet, 1);
}

const char defaultIface[]="eth0";
char *iface = NULL;

static const char *dhcpc_cmd[] = { "udhcpc",
				   "-i", NULL,
				   "-T", "11",
				   "-fqns", 
				   "/bin/dhcp.script", NULL };

static char ip[20];
static char mask[20];
static char bcast[20];

static const char *ifconfig_cmd[] = { "ifconfig", defaultIface, ip, 
				      "netmask", mask, 
				      "broadcast", bcast, NULL};

static int dhcp(const char *netif) {
  int r;
  udpc_msgbox(title, "%s: %s", MSG(TXT_SEND_BOOTP), netif);
  dhcpc_cmd[2] = netif;
  r = udpc_spawn(-1, -1, dhcpc_cmd);
  dialog_clear();
  return r;
}

static int ifconfig(const char *netif) {
  struct in_addr broadcast;
  broadcast.s_addr = udpc_config.ip.s_addr | ~udpc_config.netmask.s_addr;
  strcpy(ip, inet_ntoa(udpc_config.ip));
  strcpy(mask, inet_ntoa(udpc_config.netmask));
  strcpy(bcast, inet_ntoa(broadcast));

  ifconfig_cmd[1] = netif;
  return udpc_spawn(-1, -1, ifconfig_cmd);
}

/**
 * Gets the linkbeat status of the given interface
 * -1 link status could not be determined
 *  0 no link
 *  1 link
 */
static int checkEthernet(const char *name) {
   struct ifreq if_info;
   int fd;
   int r;

   struct ethtool_value edata;

   fd = socket(AF_INET, SOCK_DGRAM, 0);
   if(fd < 0) {
     perror("Could not make socket");
     return -1;
   }
   
   strncpy(if_info.ifr_name, name, IFNAMSIZ - 1);
   if_info.ifr_data = (char *) &edata;
   
   edata.cmd = ETHTOOL_GLINK;

   if((r = ioctl(fd, SIOCETHTOOL,&if_info)) >= 0) {
     close(fd);
     return edata.data;
   }
   close(fd);
   return -1;
}

static int netcfg(int(*fn)(const char*), const char *netif, int remember) {
  int r=fn(netif);
  if(r == 0 && remember) {
    if(iface != NULL)
      free(iface);
    iface = strdup(netif);
  }
  return r;
}

/**
 * Returns the stage when this interface should be handled
 * Parameters:
 *   name the interface
 *   bootIf the boot interface as set by the PXE loader
 */
static int getStage(const char *name, const char *bootIf) {
  int ifst;

  /* First check if interface's MAC matches hint set by PXE loader */
  if(bootIf != NULL) {
    char mac[18];
    udpc_getMac(name, mac);
    if(!strcmp(bootIf, mac))
      return 0;
  }

  /* Then prefer interface detected by previous run */
  if(iface != NULL && !strcmp(iface, name))
    return 1;

  ifst = checkEthernet(name);

  if(ifst > 0)
    /* In third round, only do those interfaces that are known
     * connected */
    return 2;
  else if(ifst < 0)
    /* In fourth round, only do those interfaces whose link
     * status is unknown (checkEthernet returned error) */
    return 3;
  else
    /* Finally, do those interfaces whose link status is
     * unconnected (on the off chance that link detection was
     * wrong) */
    return 4;
}

/**
 * Executes function fn for all network interfaces. All interfaces are
 * called until fn succeeds (returns 0). Interfaces are tried in the
 * following order:
 * - defNic set by user (if set, no others will be tried)
 * - interface matching BOOTIF
 * - interfaces who are known to have linkbeat
 * - interfaces whose linkbeat status is not known
 * - interfaces who are known not to have linkbeat
 * - if no interface has been found, eth0
 *
 * Parameters:
 *  fn       - function to call
 *  remember - remember matching interface for next round?
 * Return status is 0 in case of success, or the return status of last tried
 * interface
 */
int forAllNetInterfaces(int(*fn)(const char*), int remember) {
  int stage;
  int r=-1;
  int found=0; /* Set when one interface has been found, even if not configured
		  successfully */

  /* Boot interface suggested by PXE */
  const char *bootIf=getenv("BOOTIF");
  if(bootIf) {
    /* Trim the first 3 characters */
    if(strlen(bootIf) > 3)
      bootIf = bootIf + 3;
    else
      bootIf = NULL;
  }

  /* If config file asked explicitly for an interface, try only that one */
  if(udpc_config.defNic[0]) {
    return netcfg(fn, udpc_config.defNic, remember);
  }

  for(stage=0; r != 0 && stage<=4; stage++) {
    DIR *f = opendir("/sys/class/net");
    struct dirent *d;

    if(f == NULL) {
      perror("open");
      return -1;
    }
    
    while( (d=readdir(f)) != NULL) {
      const char *name = d->d_name;
      if(!strcmp(name, ".") ||
	 !strcmp(name, "..") ||
	 !strcmp(name, "lo"))
	/* Skip loopback interface, and "reserved" names */
	continue;

      found=1;
      if(getStage(name, bootIf) != stage)
	continue; /* Stage does not match => continue to next interface */

      r = netcfg(fn, name, remember);
      if(r == 0)
	break;
    }
    closedir(f);
  }
  if(!found) {
    /* Interface of last resort */
    r = netcfg(fn, defaultIface, 0);
  }
  return r;
}


int udpc_configureNetSettings(int forceManual, int step)
{
  readIpMacFiles();
  if(udpc_config.automatic != 1)
    forceManual=1;
  while(1) {
    switch(step) {
    case STEP_NETCFG+1:
      if(udpc_config.doDhcp!=0)
	udpc_loadConfigDhcp();
      if(setDoDhcp(forceManual) < 0)
	return -1;
      if(udpc_config.doDhcp==1) {
	int r;
	if(getenv("netwait")) {
	  sleep(atoi(getenv("netwait")));
	}

	r=forAllNetInterfaces(dhcp, 1);
	if(r)
	  udpc_display_error();
	else if(forceManual)
	  udpc_display_output();
	if(r == 0) {
	  return 0;
	}
	forceManual=1;
      } else {
	step++;
      }
      break;

    case STEP_NETCFG+2:
      if(configureIp(forceManual) < 0) {
	step--;
	forceManual=1;
      } else {
	step++;
      }
      break;

    case STEP_NETCFG+0xff:
    case STEP_NETCFG+3:      
      if(configureNetmask(forceManual) < 0) {
	step=STEP_NETCFG+2;
	forceManual=1;
      } else {
	if(forAllNetInterfaces(ifconfig, 1) == 0)
	  return 0;
	udpc_display_error();
	forceManual=1;
	step=STEP_NETCFG+2;
      }
      break;
    }
  }
}
