#define udpc_dialog_trivial_usage \
      "[-S stderrfile] [t]"
#define udpc_dialog_full_usage \
      "Udpcast's interactive dialog system\n\n" \
      "\t-S\tlog stderr messages into this file\n" \
      "\t-t\ttest mode\n"
