
module Main where

import IO
import Lib

main :: IO ()
main = do putStrLn ("show (somar 2 3)")
          putStrLn (show (somar 2 3))
          putStrLn ("Pressione qualquer tecla. . .")
          c <- getChar
          return ()