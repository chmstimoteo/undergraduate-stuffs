
module Lib where

somar :: Int -> Int -> Int
somar x y = x + y